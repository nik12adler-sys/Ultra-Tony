package com.ultratony.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.content.*
import android.graphics.*
import android.graphics.drawable.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class AppItem(val label: String, val pkg: String, val intent: Intent, val tile: Bitmap)

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private var accent = Color.parseColor("#AAF3FF")
    private var builtKey = ""
    private lateinit var clock: TextView
    private lateinit var batt: TextView
    private lateinit var term: TextView
    private lateinit var grid: GridView
    private var apps: List<AppItem> = emptyList()
    private var animated = false
    private val h = Handler(Looper.getMainLooper())
    private val log = StringBuilder()
    private val pending = StringBuilder()
    private val palette = intArrayOf(
        0xFFFFD6E0.toInt(), 0xFFD6F0FF.toInt(), 0xFFDFFFD6.toInt(), 0xFFFFF3C4.toInt(),
        0xFFE4D9FF.toInt(), 0xFFFFE0C2.toInt(), 0xFFC9FFF1.toInt(), 0xFFF0F0F0.toInt()
    )

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            h.postDelayed(this, 1000)
        }
    }
    private val pump = object : Runnable {
        override fun run() {
            if (pending.isEmpty()) return
            val n = minOf(3, pending.length)
            log.append(pending.substring(0, n)); pending.delete(0, n)
            val lines = log.toString().split("\n")
            if (lines.size > 7) { log.setLength(0); log.append(lines.takeLast(7).joinToString("\n")) }
            term.text = log.toString() + "█"
            h.postDelayed(this, 30)
        }
    }
    private val battRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            batt.text = "PWR " + (l * 100 / s) + "%" + if (ch) "  +CHG" else ""
        }
    }
    private val pkgRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun key() = prefs.getInt("accent", accent).toString() + "/" + prefs.getInt("cols", 4)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("ut", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        else window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = 0
        window.navigationBarColor = 0
        buildUi()
        reg(battRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        reg(pkgRx, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        })
        loadApps()
    }

    private fun reg(r: BroadcastReceiver, f: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(r, f)
    }

    override fun onResume() {
        super.onResume()
        if (builtKey != key()) { buildUi(); loadApps() }
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(battRx); unregisterReceiver(pkgRx) }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (::grid.isInitialized) grid.smoothScrollToPosition(0) }
    @Deprecated("home screen") override fun onBackPressed() {}

    private fun mono(t: String, sp: Float) = TextView(this).apply {
        text = t; textSize = sp; typeface = Typeface.MONOSPACE; setTextColor(accent)
    }

    private fun box(): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(6).toFloat(); setColor(0xFF0E141C.toInt())
        setStroke(dp(1), (accent and 0x00FFFFFF) or 0x66000000)
    }

    private fun press(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }
            false
        }
    }

    private fun btn(t: String, a: () -> Unit) = mono(t, 10f).apply {
        gravity = Gravity.CENTER; background = box(); setPadding(0, dp(11), 0, dp(11))
        setOnClickListener { a() }; press(this)
    }

    private fun row(vararg b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        b.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(6)
            })
        }
    }

    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun buildUi() {
        accent = prefs.getInt("accent", Color.parseColor("#AAF3FF"))
        val cols = prefs.getInt("cols", 4)
        builtKey = key()
        log.setLength(0); pending.setLength(0)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF080B10.toInt())
            setOnApplyWindowInsetsListener { v, i ->
                v.setPadding(dp(14), i.systemWindowInsetTop + dp(10), dp(14), i.systemWindowInsetBottom + dp(8)); i
            }
        }
        val title = mono("ULTRA TONY", 15f).apply {
            letterSpacing = 0.25f
            setOnLongClickListener { go(Intent(this@MainActivity, SettingsActivity::class.java)); true }
        }
        clock = mono("--:--:--", 22f)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(clock)
        }
        root.addView(head)
        batt = mono("PWR --%", 12f).apply { alpha = 0.8f }
        root.addView(batt, lp(2))

        // terminal
        term = mono("", 11f).apply { setLineSpacing(0f, 1.1f) }
        val input = EditText(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(accent)
            setHintTextColor((accent and 0x00FFFFFF) or 0x55000000); hint = "> app name"
            background = null; maxLines = 1; isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { v, _, _ -> runCmd(v.text.toString()); v.text = ""; true }
        }
        val tbox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(); setPadding(dp(10), dp(8), dp(10), dp(2))
            addView(term, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)))
            addView(input)
        }
        root.addView(tbox, lp(10))
        root.addView(HudView(this, accent).apply { background = box() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(116)).apply { topMargin = dp(10) })

        root.addView(row(
            btn("INTERNET") { go(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS)) },
            btn("BLUETOOTH") { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            btn("AIRPLANE") { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) },
            btn("DISPLAY") { go(Intent(Settings.ACTION_DISPLAY_SETTINGS)) },
            btn("CONFIG") { go(Intent(this, SettingsActivity::class.java)) }
        ), lp(10))

        root.addView(row(
            btn("PHONE") { go(Intent(Intent.ACTION_DIAL)) },
            btn("SMS") { go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)) },
            btn("GOOGLE") { openPkg(arrayOf("com.google.android.googlequicksearchbox"), Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://google.com"))) },
            btn("PLAY") { openPkg(arrayOf("com.android.vending"), Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com"))) },
            btn("YOUTUBE") { openPkg(arrayOf("com.google.android.youtube"), Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://youtube.com"))) },
            btn("FILES") { openPkg(arrayOf("com.google.android.documentsui", "com.android.documentsui", "com.mi.android.globalFileexplorer"), null) }
        ), lp(8))

        grid = GridView(this).apply {
            numColumns = cols; verticalSpacing = dp(14); selector = ColorDrawable(0)
            isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
            adapter = Adapter()
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(14) })
        setContentView(root)

        typeLine("ULTRA TONY KERNEL v0.1\nINIT UI ......... OK\nLINK APPS ....... OK\nREADY.\n")
    }

    private fun typeLine(s: String) {
        pending.append(s); h.removeCallbacks(pump); h.post(pump)
    }

    private fun runCmd(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        val m = apps.firstOrNull { it.label.contains(t, true) }
        if (m != null) { typeLine("> LAUNCH " + m.label.uppercase() + "\n"); go(m.intent) }
        else typeLine("> NOT FOUND: " + t + "\n")
    }

    private fun go(i: Intent, from: View? = null) {
        try {
            if (from != null) startActivity(i, ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle())
            else { startActivity(i); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) }
        } catch (e: Exception) { Toast.makeText(this, "N/A", Toast.LENGTH_SHORT).show() }
    }

    private fun openPkg(pkgs: Array<String>, fallback: Intent?) {
        for (p in pkgs) { packageManager.getLaunchIntentForPackage(p)?.let { go(it); return } }
        if (fallback != null) go(fallback) else Toast.makeText(this, "N/A", Toast.LENGTH_SHORT).show()
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, i, makeTile(it.activityInfo.packageName, it.loadIcon(pm)))
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list; animated = false
                (grid.adapter as BaseAdapter).notifyDataSetChanged()
                h.postDelayed({ animated = true }, 1200)
                typeLine("APPS: " + list.size + "\n")
            }
        }.start()
    }

    private fun makeTile(pkg: String, d: Drawable): Bitmap {
        val size = dp(58)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rad = dp(16).toFloat()
        c.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), rad, rad, Path.Direction.CW) })
        val col = palette[Math.abs(pkg.hashCode()) % palette.size]
        val furId = resources.getIdentifier("fur_tile", "drawable", packageName)
        var drew = false
        if (furId != 0) try {
            val f = resources.getDrawable(furId, null).constantState!!.newDrawable().mutate()
            f.colorFilter = PorterDuffColorFilter(col, PorterDuff.Mode.MULTIPLY)
            f.setBounds(0, 0, size, size); f.draw(c); drew = true
        } catch (e: Exception) {}
        if (!drew) c.drawColor(col)
        val adaptive = d is AdaptiveIconDrawable
        val fg = if (adaptive) ((d as AdaptiveIconDrawable).foreground ?: d) else d
        val sz = if (adaptive) (size * 1.45f).toInt() else (size * 0.72f).toInt()
        val o = (size - sz) / 2
        fg.setBounds(o, o, o + sz, o + sz); fg.draw(c)
        return bmp
    }

    private class Holder(val iv: ImageView, val tv: TextView)

    inner class Adapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, c: View?, parent: ViewGroup): View {
            val a = apps[p]
            val v: View
            if (c == null) {
                val size = dp(58)
                val iv = ImageView(this@MainActivity)
                val tv = mono("", 10f).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
                val l = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                    addView(iv, LinearLayout.LayoutParams(size, size))
                    addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
                }
                press(l); l.tag = Holder(iv, tv); v = l
            } else v = c
            val hd = v.tag as Holder
            hd.iv.setImageBitmap(a.tile); hd.tv.text = a.label; hd.tv.setTextColor(accent)
            v.setOnClickListener { go(a.intent, v) }
            v.animate().cancel(); v.alpha = 1f; v.translationY = 0f
            if (!animated && p < 24) {
                v.alpha = 0f; v.translationY = dp(26).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(p * 28L).setDuration(300)
                    .setInterpolator(DecelerateInterpolator()).start()
            }
            return v
        }
    }
}
