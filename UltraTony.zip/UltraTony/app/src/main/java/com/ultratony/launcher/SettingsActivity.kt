package com.ultratony.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("ut", MODE_PRIVATE)
        val acc = p.getInt("accent", Color.parseColor("#AAF3FF"))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF080B10.toInt()); setPadding(dp(18), dp(56), dp(18), dp(18))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; typeface = Typeface.MONOSPACE; setTextColor(acc); textSize = 13f
            setPadding(0, dp(18), 0, dp(6))
        }
        fun btn(t: String, a: () -> Unit) = TextView(this).apply {
            text = t; typeface = Typeface.MONOSPACE; setTextColor(acc); textSize = 13f
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat(); setColor(0xFF0E141C.toInt()); setStroke(dp(1), (acc and 0xFFFFFF) or 0x66000000)
            }
            setOnClickListener { a() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
        }
        root.addView(label("ULTRA TONY // CONFIG").apply { textSize = 16f })
        root.addView(label("GRID COLUMNS"))
        for (n in 3..5) root.addView(btn("$n COLUMNS") { p.edit().putInt("cols", n).apply(); finish() })
        root.addView(label("ACCENT COLOR"))
        listOf("CYAN" to "#AAF3FF", "GREEN" to "#7CFFB2", "AMBER" to "#FFC857", "PINK" to "#FF7AB6").forEach { (n, c) ->
            root.addView(btn(n) { p.edit().putInt("accent", Color.parseColor(c)).apply(); finish() }.apply { setTextColor(Color.parseColor(c)) })
        }
        root.addView(label("SYSTEM"))
        root.addView(btn("SET AS DEFAULT LAUNCHER") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) })
        setContentView(root)
    }
}
