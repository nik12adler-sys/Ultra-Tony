package com.ultratony.launcher

import android.app.ActivityManager
import android.content.Context
import android.graphics.*
import android.net.TrafficStats
import android.os.SystemClock
import android.view.View
import kotlin.math.*

class HudView(c: Context, private val accent: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val px: FloatArray
    private val py: FloatArray
    private val sl: FloatArray
    private val cl: FloatArray
    private val buf: Array<FloatArray>
    private val cnt = IntArray(3)
    private val alphas = intArrayOf(90, 170, 255)
    private var ang = 0f
    private val net = FloatArray(40)
    private val path = Path()
    private var lastB = bytes()
    private var lastT = SystemClock.elapsedRealtime()
    private var kbps = 0f
    private var ramTxt = "RAM --%"
    private var netTxt = "NET 0 KB/s"
    private var ramPct = 0
    private val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val mi = ActivityManager.MemoryInfo()
    private val d = c.resources.displayMetrics.density
    private val next = Runnable { invalidate() }

    init {
        val a = ArrayList<FloatArray>()
        var la = -78
        while (la <= 78) {
            var lo = 0
            while (lo < 360) {
                if (sin(lo * .05 + la * .09) + cos(lo * .11 - la * .07) > .3) {
                    val phi = Math.toRadians(la.toDouble()); val th = Math.toRadians(lo.toDouble())
                    a.add(floatArrayOf(cos(phi).toFloat(), sin(phi).toFloat(), sin(th).toFloat(), cos(th).toFloat()))
                }
                lo += 8
            }
            la += 8
        }
        px = FloatArray(a.size) { a[it][0] }; py = FloatArray(a.size) { a[it][1] }
        sl = FloatArray(a.size) { a[it][2] }; cl = FloatArray(a.size) { a[it][3] }
        buf = Array(3) { FloatArray(a.size * 2) }
        p.typeface = Typeface.MONOSPACE
    }

    private fun bytes(): Long {
        val a = TrafficStats.getTotalRxBytes(); val b = TrafficStats.getTotalTxBytes()
        return if (a < 0 || b < 0) 0 else a + b
    }

    private fun sample() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastT < 1000) return
        am.getMemoryInfo(mi)
        ramPct = (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt()
        val b = bytes()
        kbps = max(0f, (b - lastB) / 1024f / ((now - lastT) / 1000f))
        lastB = b; lastT = now
        for (i in 0 until net.size - 1) net[i] = net[i + 1]
        net[net.size - 1] = kbps
        ramTxt = "RAM $ramPct%"; netTxt = "NET " + kbps.toInt() + " KB/s"
    }

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val w = width.toFloat()
        val r = h / 2 - 6 * d; val cx = h / 2; val cy = h / 2
        p.color = accent; p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.alpha = 120
        cv.drawCircle(cx, cy, r, p)
        val ca = cos(ang); val sa = sin(ang)
        cnt.fill(0)
        for (i in px.indices) {
            val z = px[i] * (cl[i] * ca - sl[i] * sa)
            if (z > 0f) {
                val x = px[i] * (sl[i] * ca + cl[i] * sa)
                val b = if (z > .66f) 2 else if (z > .33f) 1 else 0
                val k = cnt[b]; val arr = buf[b]
                arr[k] = cx + x * r; arr[k + 1] = cy - py[i] * r; cnt[b] = k + 2
            }
        }
        p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.8f * d
        for (b in 0..2) { p.alpha = alphas[b]; cv.drawPoints(buf[b], 0, cnt[b], p) }
        ang += 0.02f
        sample()

        val x0 = h + 10 * d; val x1 = w - 10 * d
        p.alpha = 255; p.style = Paint.Style.FILL; p.textSize = 11 * d
        cv.drawText(ramTxt, x0, 20 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d
        cv.drawRect(x0, 26 * d, x1, 32 * d, p)
        p.style = Paint.Style.FILL
        cv.drawRect(x0, 26 * d, x0 + (x1 - x0) * ramPct / 100f, 32 * d, p)
        cv.drawText(netTxt, x0, 52 * d, p)
        val mx = max(50f, net.max())
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d
        path.reset()
        for (i in net.indices) {
            val x = x0 + (x1 - x0) * i / (net.size - 1)
            val y = h - 10 * d - net[i] / mx * (h - 70 * d)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        cv.drawPath(path, p)
        if (isShown) postDelayed(next, 33)
    }

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        removeCallbacks(next)
        if (v == VISIBLE) invalidate()
    }

    override fun onDetachedFromWindow() { removeCallbacks(next); super.onDetachedFromWindow() }
}
