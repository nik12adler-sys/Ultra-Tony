package com.ultratony.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser

class IconPack(
    val pkg: String,
    private val res: Resources,
    private val exact: Map<String, String>,
    private val byPkg: Map<String, String>
) {
    fun find(c: ComponentName): Drawable? {
        val name = exact[c.toString()] ?: byPkg[c.packageName] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try { ResourcesCompat.getDrawable(res, id, null) } catch (e: Exception) { null }
    }

    companion object {
        private val actions = listOf(
            "org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme"
        )
        private var cached: IconPack? = null
        private var cachedPkg: String? = null

        fun list(ctx: Context): List<Pair<String, String>> {
            val pm = ctx.packageManager
            val out = LinkedHashMap<String, String>()
            for (a in actions) {
                try {
                    for (r in pm.queryIntentActivities(Intent(a), 0)) {
                        out[r.activityInfo.packageName] = r.loadLabel(pm).toString()
                    }
                } catch (e: Exception) {
                }
            }
            return out.map { Pair(it.key, it.value) }
        }

        fun load(ctx: Context, pkg: String?): IconPack? {
            if (pkg == null) return null
            if (pkg == cachedPkg && cached != null) return cached
            return try {
                val res = ctx.packageManager.getResourcesForApplication(pkg)
                val id = res.getIdentifier("appfilter", "xml", pkg)
                val p: XmlPullParser = if (id != 0) res.getXml(id) else res.assets.openXmlResourceParser("appfilter.xml")
                val exact = HashMap<String, String>()
                val byPkg = HashMap<String, String>()
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name == "item") {
                        val comp = p.getAttributeValue(null, "component")
                        val dr = p.getAttributeValue(null, "drawable")
                        if (comp != null && dr != null) {
                            exact[comp] = dr
                            val k = comp.substringAfter("{", "").substringBefore("/")
                            if (k.isNotEmpty() && !byPkg.containsKey(k)) byPkg[k] = dr
                        }
                    }
                    ev = p.next()
                }
                val ip = IconPack(pkg, res, exact, byPkg)
                cached = ip; cachedPkg = pkg
                ip
            } catch (e: Exception) {
                null
            }
        }
    }
}
