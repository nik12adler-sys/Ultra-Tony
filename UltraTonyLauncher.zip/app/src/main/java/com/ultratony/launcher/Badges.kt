package com.ultratony.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object Badges {
    @Volatile var counts: Map<String, Int> = emptyMap()
    @Volatile var onChange: (() -> Unit)? = null
    fun get(pkg: String): Int = counts[pkg] ?: 0
}

class UltraNotificationService : NotificationListenerService() {
    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }

    private fun refresh() {
        try {
            val m = HashMap<String, Int>()
            val list = activeNotifications
            if (list != null) {
                for (n in list) {
                    val summary = (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
                    if (!n.isOngoing && !summary) m[n.packageName] = (m[n.packageName] ?: 0) + 1
                }
            }
            Badges.counts = m
            Badges.onChange?.invoke()
        } catch (e: Exception) {
        }
    }
}
