package com.ultratony.launcher

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

sealed class Entry
class AppEntry(val pkg: String) : Entry()
class FolderEntry(var name: String, val pkgs: MutableList<String>) : Entry()

class HomeModel(private val prefs: SharedPreferences) {
    val items = ArrayList<Entry>()

    fun load() {
        items.clear()
        val s = prefs.getString("layout", null) ?: return
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getString("t") == "app") {
                    items.add(AppEntry(o.getString("p")))
                } else {
                    val l = ArrayList<String>()
                    val a = o.getJSONArray("a")
                    for (j in 0 until a.length()) l.add(a.getString(j))
                    items.add(FolderEntry(o.getString("n"), l))
                }
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    fun save() {
        val arr = JSONArray()
        for (e in items) {
            val o = JSONObject()
            when (e) {
                is AppEntry -> { o.put("t", "app"); o.put("p", e.pkg) }
                is FolderEntry -> {
                    o.put("t", "folder"); o.put("n", e.name)
                    val a = JSONArray()
                    e.pkgs.forEach { a.put(it) }
                    o.put("a", a)
                }
            }
            arr.put(o)
        }
        prefs.edit().putString("layout", arr.toString()).apply()
    }

    fun reconcile(installed: List<String>) {
        if (installed.isEmpty()) return // transient empty result must not wipe folders/layout
        val set = installed.toHashSet()
        val used = HashSet<String>()
        val out = ArrayList<Entry>()
        for (e in items) {
            when (e) {
                is AppEntry -> {
                    if (e.pkg in set && used.add(e.pkg)) out.add(e)
                }
                is FolderEntry -> {
                    val keep = e.pkgs.filter { it in set && used.add(it) }
                    if (keep.isNotEmpty()) {
                        e.pkgs.clear(); e.pkgs.addAll(keep); out.add(e)
                    }
                }
            }
        }
        for (p in installed) if (used.add(p)) out.add(AppEntry(p))
        items.clear(); items.addAll(out)
        save()
    }

    fun move(from: Int, to: Int) {
        if (from == to || from !in items.indices || to !in 0..items.size) return
        val e = items.removeAt(from)
        items.add(minOf(to, items.size), e)
    }

    fun moveByPages(index: Int, delta: Int, cap: Int) {
        if (items.isEmpty()) return
        val to = (index + delta * cap).coerceIn(0, items.size - 1)
        if (to != index) move(index, to)
    }

    fun newFolder(pkg: String, name: String) {
        val idx = items.indexOfFirst { it is AppEntry && it.pkg == pkg }
        if (idx >= 0) items[idx] = FolderEntry(name, mutableListOf(pkg))
    }

    fun addToFolder(pkg: String, f: FolderEntry) {
        items.removeAll { it is AppEntry && it.pkg == pkg }
        f.pkgs.add(pkg)
    }

    fun removeFromFolder(f: FolderEntry, pkg: String) {
        val at = items.indexOf(f)
        f.pkgs.remove(pkg)
        if (f.pkgs.isEmpty()) {
            items.remove(f)
            items.add(minOf(maxOf(at, 0), items.size), AppEntry(pkg))
        } else {
            items.add(minOf(at + 1, items.size), AppEntry(pkg))
        }
    }

    fun deleteFolder(f: FolderEntry) {
        val at = items.indexOf(f)
        if (at < 0) return
        items.remove(f)
        items.addAll(at, f.pkgs.map { AppEntry(it) })
    }
}
