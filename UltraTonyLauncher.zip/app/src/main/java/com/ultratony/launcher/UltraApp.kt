package com.ultratony.launcher

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class UltraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("thread=" + t.name + "\n" + sw.toString())
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }
}
