package com.ultratony.launcher

import android.animation.ObjectAnimator
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var model: HomeModel
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var pager: ViewPager2
    private lateinit var searchRv: RecyclerView
    private lateinit var dots: TextView
    private lateinit var dock: LinearLayout
    private lateinit var batteryText: TextView
    private lateinit var batteryBar: ProgressBar
    private lateinit var card: LinearLayout
    private lateinit var widgetBox: LinearLayout
    private lateinit var widgetScroll: ScrollView

    private val pagerAdapter = PagerAdapter()
    private val searchAdapter = SearchAdapter()
    private val io = Executors.newSingleThreadExecutor()
    private var byPkg: Map<String, AppItem> = emptyMap()
    private var colorful = true
    private var torchOn = false
    private var lastLevel = 0
    private val tileBg = 0x33FFFFFF
    private val gradients = listOf(
        intArrayOf(0xFF0B0F1A.toInt(), 0xFF1A1033.toInt()),
        intArrayOf(0xFF0F2027.toInt(), 0xFF2C5364.toInt()),
        intArrayOf(0xFF200122.toInt(), 0xFF6F0000.toInt()),
        intArrayOf(0xFF000000.toInt(), 0xFF434343.toInt())
    )

    // Widgets
    private val widgetHost by lazy { AppWidgetHost(this, 1024) }
    private val awm by lazy { AppWidgetManager.getInstance(this) }
    private var pendingId = -1
    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { onWidgetPicked(it) }
    private val configLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) saveAndShowWidget(pendingId) else widgetHost.deleteAppWidgetId(pendingId)
        }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateBattery(i)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cols() = prefs.getInt("cols", 4)
    private fun cap() = cols() * 5
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ut", MODE_PRIVATE)
        model = HomeModel(prefs)
        model.load()
        window.statusBarColor = 0xFF0B0F1A.toInt()
        window.navigationBarColor = 0xFF1A1033.toInt()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "Ultra Tony"; textSize = 24f; setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(TextView(this).apply {
            text = "⚙️"; textSize = 22f; setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        root.addView(header)

        // Status card
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0x22FFFFFF, 24)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "hh:mm"
            textSize = 36f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        batteryText = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE) }
        topRow.addView(batteryText)
        card.addView(topRow)
        batteryBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(0xFF69DB7C.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }
        card.addView(batteryBar, LinearLayout.LayoutParams(MATCH, dp(8)).apply {
            topMargin = dp(8); bottomMargin = dp(12)
        })
        val tiles = LinearLayout(this)
        val tileList = listOf(
            tile("📶", "Wi-Fi") { open(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS) },
            tile("🌐", "Data") { open(Settings.ACTION_NETWORK_OPERATOR_SETTINGS) },
            tile("🔵", "Bluetooth") { open(Settings.ACTION_BLUETOOTH_SETTINGS) },
            tile("🔦", "Torch") { toggleTorch(it) }
        )
        tileList.forEach {
            tiles.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        card.addView(tiles)
        root.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8); bottomMargin = dp(8) })

        // Search
        search = EditText(this).apply {
            hint = "🔍  جستجو..."
            setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true)
            background = rounded(0x22FFFFFF, 20)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val q = e?.toString() ?: ""
                    searchAdapter.filter(q)
                    val on = q.isNotBlank()
                    searchRv.visibility = if (on) View.VISIBLE else View.GONE
                    pager.visibility = if (on) View.INVISIBLE else View.VISIBLE
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })

        // Widgets page content
        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(16)) }
        widgetBox.addView(TextView(this).apply {
            text = "➕  افزودن ویجت"; textSize = 16f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x22FFFFFF, 18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { startWidgetPick() }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        widgetScroll = ScrollView(this).apply { addView(widgetBox) }
        (prefs.getString("widgets", "") ?: "").split(",").filter { it.isNotBlank() }.forEach {
            addWidgetView(it.toInt())
        }

        // Pager + search results
        pager = ViewPager2(this).apply {
            adapter = pagerAdapter
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) { updateDots(position) }
            })
            setCurrentItem(1, false)
        }
        searchRv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, cols())
            adapter = searchAdapter
            visibility = View.GONE
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = FrameLayout(this)
        content.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(searchRv, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dots = TextView(this).apply {
            textSize = 10f; setTextColor(0xAAFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        root.addView(dots, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        // Dock
        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(0x22FFFFFF, 28)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (search.text.isNotEmpty()) search.setText("")
                else if (pager.currentItem != 1) pager.currentItem = 1
            }
        })

        // Entry animation
        card.alpha = 0f; card.translationY = -dp(40).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(500).setInterpolator(DecelerateInterpolator()).start()
        tileList.forEachIndexed { i, t ->
            t.alpha = 0f; t.scaleX = 0.6f; t.scaleY = 0.6f
            t.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150L + i * 70L).setDuration(400)
                .setInterpolator(OvershootInterpolator()).start()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) {
            search.setText("")
            pager.currentItem = 1
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (i != null) updateBattery(i)
        try { widgetHost.startListening() } catch (_: Exception) {}
        Badges.onChange = { runOnUiThread { refreshBadges() } }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { widgetHost.stopListening() } catch (_: Exception) {}
        Badges.onChange = null
    }

    override fun onResume() {
        super.onResume()
        colorful = prefs.getBoolean("colorful", true)
        (searchRv.layoutManager as GridLayoutManager).spanCount = cols()
        applyBackground()
        reload()
    }

    private fun reload() {
        io.execute {
            try {
                val all = IconMaker.loadApps(this, colorful)
                val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
                val visible = all.filter { it.pkg !in hidden }
                runOnUiThread {
                    try {
                        byPkg = visible.associateBy { it.pkg }
                        model.reconcile(visible.map { it.pkg })
                        searchAdapter.submit(visible)
                        pagerAdapter.notifyDataSetChanged()
                        updateDots(pager.currentItem)
                        buildDock(all)
                    } catch (e: Throwable) {
                        toast("خطا: " + e.toString())
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { toast("خطا: " + e.toString()) }
            }
        }
    }

    private fun refresh() {
        model.save()
        pagerAdapter.notifyDataSetChanged()
        updateDots(pager.currentItem)
    }

    private fun refreshBadges() {
        val inner = pager.getChildAt(0) as? RecyclerView
        if (inner != null) {
            for (i in 0 until inner.childCount) {
                (inner.getChildAt(i) as? RecyclerView)?.adapter?.notifyDataSetChanged()
            }
        }
        searchAdapter.notifyDataSetChanged()
    }

    private fun updateDots(pos: Int) {
        val total = pagerAdapter.itemCount
        dots.text = if (total <= 1) "" else (0 until total).joinToString("  ") { if (it == pos) "●" else "○" }
    }

    // ---------- Helpers ----------
    private fun open(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator()).start()
            }
            false
        }
    }

    private fun tile(emoji: String, label: String, onClick: (View) -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(tileBg, 16)
            setPadding(0, dp(10), 0, dp(10))
            addView(TextView(context).apply { text = emoji; textSize = 22f; gravity = Gravity.CENTER })
            addView(TextView(context).apply { text = label; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            setOnClickListener(onClick)
            press(this)
        }

    private fun toggleTorch(v: View) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            v.background = rounded(if (torchOn) 0xFFFFD43B.toInt() else tileBg, 16)
        } catch (_: Exception) { torchOn = false }
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = level * 100 / scale
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = (if (charging) "⚡ " else "🔋 ") + pct + "%"
        batteryBar.progressTintList = ColorStateList.valueOf(
            if (pct <= 20 && !charging) 0xFFFF6B6B.toInt() else 0xFF69DB7C.toInt()
        )
        ObjectAnimator.ofInt(batteryBar, "progress", lastLevel, pct).setDuration(700).start()
        lastLevel = pct
    }

    private fun applyBackground() {
        val f = File(filesDir, "bg.jpg")
        if (f.exists()) {
            io.execute {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                runOnUiThread {
                    if (bmp != null) {
                        root.background = BitmapDrawable(resources, bmp)
                        root.foreground = ColorDrawable(0x66000000)
                    }
                }
            }
        } else {
            val g = gradients[prefs.getInt("bgGrad", 0) % gradients.size]
            root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, g)
            root.foreground = null
        }
    }

    private fun launch(v: View, pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        val o = ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
        startActivity(i, o.toBundle())
    }

    private fun resolvePkg(i: Intent): String? =
        packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName

    private fun buildDock(apps: List<AppItem>) {
        val wanted = ArrayList<String>()
        fun add(p: String?) { if (p != null && p != "android" && !wanted.contains(p)) wanted.add(p) }
        add(resolvePkg(Intent(Intent.ACTION_DIAL)))
        add(resolvePkg(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)))
        add("com.android.vending")
        add(listOf("com.google.android.documentsui", "com.android.documentsui",
            "com.sec.android.app.myfiles", "com.google.android.apps.nbu.files")
            .firstOrNull { p -> apps.any { it.pkg == p } })
        dock.removeAllViews()
        wanted.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { app ->
            val iv = ImageView(this).apply {
                setImageBitmap(app.icon)
                setOnClickListener { launch(it, app.pkg) }
                press(this)
            }
            dock.addView(iv, LinearLayout.LayoutParams(0, dp(60), 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
    }

    // ---------- Widgets ----------
    private fun startWidgetPick() {
        try {
            pendingId = widgetHost.allocateAppWidgetId()
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId)
                .putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_INFO, ArrayList())
                .putParcelableArrayListExtra(AppWidgetManager.EXTRA_CUSTOM_EXTRAS, ArrayList())
            pickLauncher.launch(i)
        } catch (e: Exception) { toast("ویجت در این گوشی پشتیبانی نمی‌شود") }
    }

    private fun onWidgetPicked(r: ActivityResult) {
        val id = r.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId) ?: pendingId
        if (r.resultCode != RESULT_OK) { widgetHost.deleteAppWidgetId(id); return }
        pendingId = id
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { widgetHost.deleteAppWidgetId(id); toast("افزودن ویجت ناموفق بود"); return }
        if (info.configure != null) {
            try {
                configLauncher.launch(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(info.configure)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                )
            } catch (e: Exception) { saveAndShowWidget(id) }
        } else saveAndShowWidget(id)
    }

    private fun saveAndShowWidget(id: Int) {
        val ids = (prefs.getString("widgets", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
        ids.add(id.toString())
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
        addWidgetView(id)
    }

    private fun addWidgetView(id: Int) {
        val info = awm.getAppWidgetInfo(id) ?: return
        val hv = widgetHost.createView(applicationContext, id, info)
        hv.setAppWidget(id, info)
        val frame = FrameLayout(this)
        frame.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
        val x = TextView(this).apply {
            text = "✕"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(0x99000000.toInt(), 14)
            setOnClickListener { removeWidget(id, frame) }
        }
        frame.addView(x, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        })
        widgetBox.addView(frame, LinearLayout.LayoutParams(MATCH, maxOf(info.minHeight, dp(90))).apply { bottomMargin = dp(10) })
    }

    private fun removeWidget(id: Int, v: View) {
        try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
        widgetBox.removeView(v)
        val ids = (prefs.getString("widgets", "") ?: "").split(",").filter { it.isNotBlank() && it != id.toString() }
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
    }

    // ---------- Cells ----------
    inner class VH(val box: LinearLayout, val img: ImageView, val label: TextView, val badge: TextView) :
        RecyclerView.ViewHolder(box)

    private fun makeVH(ctx: Context): VH {
        val size = dp(prefs.getInt("iconDp", 60))
        val img = ImageView(ctx)
        val badge = TextView(ctx).apply {
            textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(0xFFFF3B30.toInt(), 9)
            setPadding(dp(5), 0, dp(5), 0); minWidth = dp(18)
            visibility = View.GONE
        }
        val frame = FrameLayout(ctx).apply {
            addView(img, FrameLayout.LayoutParams(size, size))
            addView(badge, FrameLayout.LayoutParams(WRAP, dp(18), Gravity.TOP or Gravity.END))
        }
        val label = TextView(ctx).apply {
            textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(frame, LinearLayout.LayoutParams(size, size))
            addView(label, LinearLayout.LayoutParams(MATCH, WRAP))
            layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
        }
        press(box)
        return VH(box, img, label, badge)
    }

    private fun setBadge(h: VH, n: Int) {
        if (n > 0) { h.badge.text = if (n > 9) "9+" else n.toString(); h.badge.visibility = View.VISIBLE }
        else h.badge.visibility = View.GONE
    }

    private fun bindApp(h: VH, app: AppItem) {
        h.img.setImageBitmap(app.icon)
        h.label.text = app.label
        h.label.visibility = if (prefs.getBoolean("labels", true)) View.VISIBLE else View.GONE
        setBadge(h, Badges.get(app.pkg))
    }

    private fun bindFolder(h: VH, f: FolderEntry) {
        val kids = f.pkgs.mapNotNull { byPkg[it]?.icon }
        h.img.setImageBitmap(IconMaker.folder(this, kids, colorful))
        h.label.text = f.name
        h.label.visibility = if (prefs.getBoolean("labels", true)) View.VISIBLE else View.GONE
        setBadge(h, f.pkgs.sumOf { Badges.get(it) })
    }

    // ---------- Pager ----------
    private fun pageCount() = maxOf(1, (model.items.size + cap() - 1) / cap())
    private fun pageSize(page: Int) =
        maxOf(0, minOf(model.items.size, (page + 1) * cap()) - page * cap())

    inner class Plain(v: View) : RecyclerView.ViewHolder(v)

    inner class PagerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = 1 + pageCount()
        override fun getItemViewType(position: Int) = if (position == 0) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val lp = ViewGroup.LayoutParams(MATCH, MATCH)
            return if (viewType == 0) {
                Plain(FrameLayout(parent.context).apply { layoutParams = lp })
            } else {
                val rv = RecyclerView(parent.context).apply {
                    layoutParams = lp
                    layoutManager = GridLayoutManager(parent.context, cols())
                    overScrollMode = View.OVER_SCROLL_NEVER
                }
                ItemTouchHelper(DragCb()).attachToRecyclerView(rv)
                Plain(rv)
            }
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            if (position == 0) {
                val box = h.itemView as FrameLayout
                (widgetScroll.parent as? ViewGroup)?.removeView(widgetScroll)
                box.addView(widgetScroll, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                val rv = h.itemView as RecyclerView
                (rv.layoutManager as GridLayoutManager).spanCount = cols()
                rv.adapter = PageGridAdapter(position - 1)
            }
        }
    }

    inner class PageGridAdapter(val page: Int) : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = pageSize(page)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = makeVH(parent.context)

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = model.items.getOrNull(page * cap() + position) ?: return
            when (e) {
                is AppEntry -> {
                    val app = byPkg[e.pkg]
                    if (app != null) {
                        bindApp(h, app)
                        h.box.setOnClickListener { launch(h.img, app.pkg) }
                    }
                }
                is FolderEntry -> {
                    bindFolder(h, e)
                    h.box.setOnClickListener { openFolder(e) }
                }
            }
        }
    }

    inner class DragCb : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
    ) {
        private var moved = false

        override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val a = rv.adapter as? PageGridAdapter ?: return false
            val from = vh.bindingAdapterPosition
            val to = target.bindingAdapterPosition
            if (from < 0 || to < 0) return false
            model.move(a.page * cap() + from, a.page * cap() + to)
            a.notifyItemMoved(from, to)
            moved = true
            return true
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

        override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
            super.onSelectedChanged(vh, actionState)
            if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                moved = false
                vh?.itemView?.animate()?.scaleX(1.12f)?.scaleY(1.12f)?.setDuration(120)?.start()
            }
        }

        override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
            super.clearView(rv, vh)
            vh.itemView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            val a = rv.adapter as? PageGridAdapter ?: return
            val pos = vh.bindingAdapterPosition
            if (moved) {
                model.save()
                moved = false
            } else if (pos >= 0) {
                showMenu(a.page * cap() + pos)
            }
        }
    }

    inner class SearchAdapter : RecyclerView.Adapter<VH>() {
        private var all: List<AppItem> = emptyList()
        private var items: List<AppItem> = emptyList()
        private var q = ""
        fun submit(l: List<AppItem>) { all = l; filter(q) }
        fun filter(query: String) {
            q = query
            val k = query.trim().lowercase()
            items = if (k.isEmpty()) all else all.filter { it.label.lowercase().contains(k) }
            notifyDataSetChanged()
        }
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = makeVH(parent.context)
        override fun onBindViewHolder(h: VH, position: Int) {
            val app = items[position]
            bindApp(h, app)
            h.box.setOnClickListener { launch(h.img, app.pkg) }
        }
    }

    // ---------- Menus and folders ----------
    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("تأیید") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) ok(t)
            }
            .setNegativeButton("لغو", null).show()
    }

    private fun showMenu(index: Int) {
        val e = model.items.getOrNull(index) ?: return
        if (e is AppEntry) {
            val app = byPkg[e.pkg] ?: return
            val opts = arrayOf(
                "اطلاعات برنامه", "حذف برنامه", "پنهان کردن از لانچر", "ساخت پوشهٔ جدید",
                "افزودن به پوشه", "انتقال به صفحهٔ بعد", "انتقال به صفحهٔ قبل"
            )
            AlertDialog.Builder(this).setTitle(app.label).setItems(opts) { _, w ->
                val uri = Uri.parse("package:" + e.pkg)
                when (w) {
                    0 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    1 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                    2 -> {
                        val set = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
                        set.add(e.pkg)
                        prefs.edit().putStringSet("hidden", set).apply()
                        reload()
                    }
                    3 -> askText("نام پوشه", "") { name -> model.newFolder(e.pkg, name); refresh() }
                    4 -> {
                        val folders = model.items.filterIsInstance<FolderEntry>()
                        if (folders.isEmpty()) toast("هنوز پوشه‌ای نساخته‌اید")
                        else AlertDialog.Builder(this).setTitle("انتخاب پوشه")
                            .setItems(folders.map { it.name }.toTypedArray()) { _, i ->
                                model.addToFolder(e.pkg, folders[i]); refresh()
                            }.show()
                    }
                    5 -> { model.moveByPages(index, 1, cap()); refresh() }
                    6 -> { model.moveByPages(index, -1, cap()); refresh() }
                }
            }.show()
        } else if (e is FolderEntry) {
            val opts = arrayOf("باز کردن", "تغییر نام", "حذف پوشه", "انتقال به صفحهٔ بعد", "انتقال به صفحهٔ قبل")
            AlertDialog.Builder(this).setTitle(e.name).setItems(opts) { _, w ->
                when (w) {
                    0 -> openFolder(e)
                    1 -> askText("نام جدید", e.name) { n -> e.name = n; refresh() }
                    2 -> { model.deleteFolder(e); refresh() }
                    3 -> { model.moveByPages(index, 1, cap()); refresh() }
                    4 -> { model.moveByPages(index, -1, cap()); refresh() }
                }
            }.show()
        }
    }

    private fun openFolder(f: FolderEntry) {
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        var dlg: AlertDialog? = null
        f.pkgs.toList().forEach { pkg ->
            val app = byPkg[pkg] ?: return@forEach
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            cell.addView(ImageView(this).apply { setImageBitmap(app.icon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
            cell.addView(TextView(this).apply {
                text = app.label; textSize = 10f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(64), WRAP))
            cell.setOnClickListener { dlg?.dismiss(); launch(it, pkg) }
            cell.setOnLongClickListener {
                dlg?.dismiss()
                model.removeFromFolder(f, pkg)
                refresh()
                true
            }
            grid.addView(cell)
        }
        dlg = AlertDialog.Builder(this)
            .setTitle(f.name + "  (نگه‌دارید تا بیرون بیاید)")
            .setView(grid)
            .show()
    }
}
