package com.ultratony.launcher

import android.animation.ObjectAnimator
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var model: HomeModel
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var pager: ViewPager2
    private lateinit var searchRv: RecyclerView
    private lateinit var dots: TextView
    private lateinit var dock: LinearLayout
    private lateinit var batteryText: TextView
    private lateinit var batteryBar: ProgressBar
    private lateinit var card: LinearLayout
    private lateinit var widgetBox: LinearLayout
    private lateinit var widgetScroll: ScrollView

    private val pagerAdapter = PagerAdapter()
    private val searchAdapter = SearchAdapter()
    private val io = Executors.newSingleThreadExecutor()
    private var byPkg: Map<String, AppItem> = emptyMap()
    private var colorful = true
    private var torchOn = false
    private var lastLevel = 0
    private val tileBg = 0x33FFFFFF
    private val gradients = listOf(
        intArrayOf(0xFF0B0F1A.toInt(), 0xFF1A1033.toInt()),
        intArrayOf(0xFF0F2027.toInt(), 0xFF2C5364.toInt()),
        intArrayOf(0xFF200122.toInt(), 0xFF6F0000.toInt()),
        intArrayOf(0xFF000000.toInt(), 0xFF434343.toInt())
    )

    // Widgets
    private val widgetHost by lazy { AppWidgetHost(this, 1024) }
    private val awm by lazy { AppWidgetManager.getInstance(this) }
    private var pendingId = -1
    private val REQ_BIND = 7001
    private val REQ_CFG = 7002

    // State / performance
    private val uiHandler = Handler(Looper.getMainLooper())
    private val badgeRunnable = Runnable { refreshBadges() }
    private val pagePool = RecyclerView.RecycledViewPool().apply { setMaxRecycledViews(0, 60) }
    private val folderCache = HashMap<String, Bitmap>()
    private var appsSig = ""
    private var settingsSig = ""
    private var bgSig = ""
    private var iconPx = 0
    private var labelsOn = true
    private var torchId: String? = null
    private var torchTile: View? = null
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (torchId == null) torchId = cameraId else if (cameraId != torchId) return
            torchOn = enabled
            torchTile?.background = rounded(if (enabled) 0xFFFFD43B.toInt() else tileBg, 16)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = updateBattery(i)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cols() = prefs.getInt("cols", 4)
    private var rowsFit = 5
    private fun iconSize(): Int {
        val want = dp(prefs.getInt("iconDp", 68))
        val colW = (resources.displayMetrics.widthPixels - dp(32)) / cols() - dp(8)
        return minOf(want, colW)
    }
    private var layoutVer = 0L
    private fun cap() = cols() * rowsFit

    // Page capacity follows the real screen height, so pages hold exactly what fits (no half-empty pages).
    private fun recomputeRows(h: Int) {
        if (h <= 0 || !::pager.isInitialized || !::model.isInitialized) return
        val icon = iconSize()
        val cell = dp(16) + icon + (if (labelsOn) dp(22) else 0)
        val r = (h / cell).coerceIn(2, 8)
        if (r != rowsFit) {
            rowsFit = r
            pagerAdapter.notifyDataSetChanged()
            updateDots(pager.currentItem)
        }
    }
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private var ok = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = File(filesDir, "crash.txt")
        if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) && crash.exists()) {
            startActivity(Intent(this, CrashLogActivity::class.java))
            finish()
            return
        }
        try {
            build()
            ok = true
        } catch (e: Throwable) {
            showError(e)
        }
    }

    private fun showError(e: Throwable) {
        val sw = java.io.StringWriter()
        e.printStackTrace(java.io.PrintWriter(sw))
        try { File(filesDir, "crash.txt").writeText(sw.toString()) } catch (_: Throwable) {}
        val tv = TextView(this).apply {
            text = sw.toString().take(2500)
            textSize = 13f; setTextColor(0xFFFFB4B4.toInt()); setTextIsSelectable(true)
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0F1A.toInt()); addView(tv) })
    }

    private fun build() {
        prefs = getSharedPreferences("ut", MODE_PRIVATE)
        model = HomeModel(prefs)
        model.load()
        layoutVer = prefs.getLong("layoutVer", 0L)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        // Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "Ultra Tony"; textSize = 30f; setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(TextView(this).apply {
            text = "⚙️"; textSize = 28f; setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { safeStart(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        root.addView(header)

        // Status card
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0x22FFFFFF, 24)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val credit = TextView(this).apply {
            text = "ساخته شده توسط ماهان عربی سازه Rp"
            textSize = 15f; gravity = Gravity.CENTER; maxLines = 1
            textDirection = View.TEXT_DIRECTION_RTL
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFD43B.toInt())
            post {
                val w = paint.measureText(text.toString()).coerceAtLeast(1f)
                paint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(
                        0xFFFF6B6B.toInt(), 0xFFFFA94D.toInt(), 0xFFFFD43B.toInt(),
                        0xFF69DB7C.toInt(), 0xFF4DABF7.toInt(), 0xFFDA77F2.toInt()
                    ),
                    null, Shader.TileMode.CLAMP
                )
                invalidate()
            }
        }
        card.addView(credit, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(2)
        })
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "hh:mm"
            textSize = 52f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        batteryText = TextView(this).apply { textSize = 20f; setTextColor(Color.WHITE) }
        topRow.addView(batteryText)
        card.addView(topRow)
        batteryBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(0xFF69DB7C.toInt())
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }
        card.addView(batteryBar, LinearLayout.LayoutParams(MATCH, dp(8)).apply {
            topMargin = dp(8); bottomMargin = dp(12)
        })
        val tiles = LinearLayout(this)
        val tileList = listOf(
            tile("📶", "Wi-Fi") { open(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS) },
            tile("🌐", "Data") { open(Settings.ACTION_NETWORK_OPERATOR_SETTINGS) },
            tile("🔵", "Bluetooth") { open(Settings.ACTION_BLUETOOTH_SETTINGS) },
            tile("🔦", "Torch") { toggleTorch(it) }
        )
        tileList.forEach {
            tiles.addView(it, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        torchTile = tileList[3]
        card.addView(tiles)
        root.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8); bottomMargin = dp(8) })

        // Search
        search = EditText(this).apply {
            hint = "🔍  جستجو (نگه‌دارید: پوشه)"
            setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
            textSize = 18f; setSingleLine(true)
            background = rounded(0x22FFFFFF, 20)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) {
                    val q = e?.toString() ?: ""
                    searchAdapter.filter(q)
                    val on = q.isNotBlank()
                    searchRv.visibility = if (on) View.VISIBLE else View.GONE
                    pager.visibility = if (on) View.INVISIBLE else View.VISIBLE
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })

        // Widgets page content
        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(16)) }
        widgetBox.addView(TextView(this).apply {
            text = "➕  افزودن ویجت"; textSize = 19f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x22FFFFFF, 18)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { startWidgetPick() }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        widgetScroll = ScrollView(this).apply { addView(widgetBox) }
        (prefs.getString("widgets", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }.forEach {
            addWidgetView(it)
        }

        // Pager + search results
        pager = ViewPager2(this).apply {
            adapter = pagerAdapter
            offscreenPageLimit = 1
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) { updateDots(position) }
            })
        }
        searchRv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, cols())
            adapter = searchAdapter
            visibility = View.GONE
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = FrameLayout(this)
        content.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))
        content.addView(searchRv, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        content.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) recomputeRows(b - t)
        }

        dots = TextView(this).apply {
            textSize = 12f; setTextColor(0xAAFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        root.addView(dots, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        pager.setCurrentItem(1, false)

        // Dock
        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(0x22FFFFFF, 28)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (search.text.isNotEmpty()) search.setText("")
                else if (pager.currentItem != 1) pager.currentItem = 1
            }
        })

        // Entry animation
        card.alpha = 0f; card.translationY = -dp(40).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(500).setInterpolator(DecelerateInterpolator()).start()
        tileList.forEachIndexed { i, t ->
            t.alpha = 0f; t.scaleX = 0.6f; t.scaleY = 0.6f
            t.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(150L + i * 70L).setDuration(400)
                .setInterpolator(OvershootInterpolator()).start()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (!ok) return
        if (intent.action == Intent.ACTION_MAIN) {
            search.setText("")
            pager.currentItem = 1
        }
    }

    override fun onStart() {
        super.onStart()
        if (!ok) return
        ContextCompat.registerReceiver(this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (i != null) updateBattery(i)
        try { widgetHost.startListening() } catch (_: Exception) {}
        Badges.onChange = { uiHandler.removeCallbacks(badgeRunnable); uiHandler.postDelayed(badgeRunnable, 250) }
        try { (getSystemService(Context.CAMERA_SERVICE) as CameraManager).registerTorchCallback(torchCb, uiHandler) } catch (_: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        if (!ok) return
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { widgetHost.stopListening() } catch (_: Exception) {}
        Badges.onChange = null
        uiHandler.removeCallbacks(badgeRunnable)
        try { (getSystemService(Context.CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(torchCb) } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (!ok) return
        colorful = prefs.getBoolean("colorful", true)
        labelsOn = prefs.getBoolean("labels", true)
        iconPx = iconSize()
        val hiddenSig = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).sorted().joinToString(",")
        val sig = "${cols()}|${prefs.getInt("iconDp", 68)}|$labelsOn|$colorful|${prefs.getString("iconpack", "")}|$hiddenSig"
        val lv = prefs.getLong("layoutVer", 0L)
        val layoutChanged = lv != layoutVer
        if (layoutChanged) { layoutVer = lv; model.load() }
        val changed = sig != settingsSig || layoutChanged
        settingsSig = sig
        if (changed) {
            folderCache.clear()
            (searchRv.layoutManager as GridLayoutManager).spanCount = cols()
            recomputeRows(pager.height)
        }
        applyBackground()
        reload(changed)
    }

    // Rebuilds the grid only when something really changed (no flicker, no needless work).
    private fun reload(force: Boolean) {
        io.execute {
            try {
                val all = IconMaker.loadApps(this, colorful)
                val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
                val visible = all.filter { it.pkg !in hidden }
                val sig = visible.joinToString(",") { it.pkg }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        byPkg = visible.associateBy { it.pkg }
                        if (force || sig != appsSig) {
                            appsSig = sig
                            folderCache.clear()
                            model.reconcile(visible.map { it.pkg })
                            searchAdapter.submit(visible)
                            pagerAdapter.notifyDataSetChanged()
                            updateDots(pager.currentItem)
                            buildDock(all)
                        }
                    } catch (e: Throwable) {
                        toast("خطا: " + e.toString())
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { toast("خطا: " + e.toString()) }
            }
        }
    }

    private fun refresh() {
        model.save()
        folderCache.clear()
        pagerAdapter.notifyDataSetChanged()
        updateDots(pager.currentItem)
    }

    private fun refreshBadges() {
        val inner = pager.getChildAt(0) as? RecyclerView
        if (inner != null) {
            for (i in 0 until inner.childCount) {
                val a = (inner.getChildAt(i) as? RecyclerView)?.adapter ?: continue
                a.notifyItemRangeChanged(0, a.itemCount, "badge")
            }
        }
        searchAdapter.notifyItemRangeChanged(0, searchAdapter.itemCount, "badge")
    }

    private fun updateDots(pos: Int) {
        if (!::dots.isInitialized) return
        val total = pagerAdapter.itemCount
        dots.text = if (total <= 1) "" else (0 until total).joinToString("  ") { if (it == pos) "●" else "○" }
    }

    // ---------- Helpers ----------
    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { toast("این کار در این گوشی ممکن نیست") }
    }

    private fun open(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    private fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator()).start()
            }
            false
        }
    }

    private fun tile(emoji: String, label: String, onClick: (View) -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(tileBg, 16)
            setPadding(0, dp(14), 0, dp(14))
            addView(TextView(context).apply { text = emoji; textSize = 28f; gravity = Gravity.CENTER })
            addView(TextView(context).apply { text = label; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            setOnClickListener(onClick)
            press(this)
        }

    private fun toggleTorch(v: View) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = torchId ?: cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }?.also { torchId = it } ?: return
            cm.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            toast("چراغ‌قوه در دسترس نیست")
        }
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = level * 100 / scale
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = (if (charging) "⚡ " else "🔋 ") + pct + "%"
        batteryBar.progressTintList = ColorStateList.valueOf(
            if (pct <= 20 && !charging) 0xFFFF6B6B.toInt() else 0xFF69DB7C.toInt()
        )
        ObjectAnimator.ofInt(batteryBar, "progress", lastLevel, pct).setDuration(700).start()
        lastLevel = pct
    }

    // Background lives on the WINDOW (behind everything), so icons/text are never dimmed or blurred.
    private fun applyBackground() {
        val f = File(filesDir, "bg.jpg")
        if (f.exists()) {
            val sig = "f" + f.lastModified() + ":" + f.length()
            if (sig == bgSig) return
            bgSig = sig
            io.execute {
                val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Throwable) { null }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (bmp != null && bgSig == sig) window.setBackgroundDrawable(BgDrawable(bmp))
                    else if (bmp == null) bgSig = ""
                }
            }
        } else {
            val idx = prefs.getInt("bgGrad", 0) % gradients.size
            val sig = "g$idx"
            if (sig == bgSig) return
            bgSig = sig
            window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, gradients[idx]))
        }
    }

    private fun launch(v: View, pkg: String) {
        try {
            val i = packageManager.getLaunchIntentForPackage(pkg)
            if (i == null) { toast("برنامه پیدا نشد"); return }
            val o = ActivityOptions.makeScaleUpAnimation(v, 0, 0, maxOf(v.width, 1), maxOf(v.height, 1))
            startActivity(i, o.toBundle())
        } catch (e: Exception) {
            toast("اجرای برنامه ممکن نشد")
        }
    }

    private fun resolvePkg(i: Intent): String? =
        packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName

    private fun buildDock(apps: List<AppItem>) {
        val wanted = ArrayList<String>()
        fun add(p: String?) { if (p != null && p != "android" && !wanted.contains(p)) wanted.add(p) }
        add(resolvePkg(Intent(Intent.ACTION_DIAL)))
        add(resolvePkg(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)))
        add("com.android.vending")
        add(listOf("com.google.android.documentsui", "com.android.documentsui",
            "com.sec.android.app.myfiles", "com.google.android.apps.nbu.files")
            .firstOrNull { p -> apps.any { it.pkg == p } })
        dock.removeAllViews()
        wanted.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.forEach { app ->
            val iv = ImageView(this).apply {
                setImageBitmap(app.icon)
                setOnClickListener { launch(it, app.pkg) }
                press(this)
            }
            dock.addView(iv, LinearLayout.LayoutParams(0, dp(68), 1f).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
    }

    // ---------- Widgets ----------
    private fun startWidgetPick() {
        try {
            val pm = packageManager
            val items = awm.installedProviders
                .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
                .map { p ->
                    val appLabel = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
                    } catch (e: Exception) { p.provider.packageName }
                    val wl0: String? = try { p.loadLabel(pm) } catch (e: Exception) { null }
                    Triple(p, appLabel, wl0 ?: appLabel)
                }
                .sortedBy { it.second.lowercase() }
            if (items.isEmpty()) { toast("ویجتی روی گوشی پیدا نشد"); return }
            val names = items.map { if (it.second == it.third) it.second else it.second + " — " + it.third }.toTypedArray()
            AlertDialog.Builder(this).setTitle("افزودن ویجت")
                .setItems(names) { _, i -> bindWidget(items[i].first) }
                .setNegativeButton("لغو", null).show()
        } catch (e: Exception) {
            toast("ویجت در این گوشی پشتیبانی نمی‌شود")
        }
    }

    @Suppress("DEPRECATION")
    private fun bindWidget(p: AppWidgetProviderInfo) {
        try {
            val id = widgetHost.allocateAppWidgetId()
            pendingId = id
            if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) {
                afterBound(id)
            } else {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
                startActivityForResult(i, REQ_BIND)
            }
        } catch (e: Exception) {
            dropPending()
            toast("افزودن ویجت ناموفق بود")
        }
    }

    private fun afterBound(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { dropPending(); toast("افزودن ویجت ناموفق بود"); return }
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CFG, null)
            } catch (e: Exception) { saveAndShowWidget(id) }
        } else saveAndShowWidget(id)
    }

    private fun dropPending() {
        if (pendingId != -1) { try { widgetHost.deleteAppWidgetId(pendingId) } catch (_: Exception) {} }
        pendingId = -1
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBound(pendingId) else dropPending()
            REQ_CFG -> if (resultCode == RESULT_OK) saveAndShowWidget(pendingId) else dropPending()
        }
    }

    private fun widgetIds() = (prefs.getString("widgets", "") ?: "").split(",").filter { it.isNotBlank() }

    private fun saveAndShowWidget(id: Int) {
        val ids = widgetIds().toMutableList()
        ids.add(id.toString())
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
        pendingId = -1
        addWidgetView(id)
    }

    private fun forgetWidget(id: Int) {
        try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
        prefs.edit().putString("widgets", widgetIds().filter { it != id.toString() }.joinToString(",")).apply()
    }

    private fun addWidgetView(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { forgetWidget(id); return }
        val hv0 = try { widgetHost.createView(applicationContext, id, info) } catch (e: Exception) { null }
        val hv = hv0 ?: return
        val dm = resources.displayMetrics
        val wDp = ((dm.widthPixels - dp(32)) / dm.density).toInt()
        val hPx = maxOf(info.minHeight, dp(90))
        val hDp = (hPx / dm.density).toInt()
        try { hv.updateAppWidgetSize(Bundle(), wDp, hDp, wDp, hDp) } catch (_: Exception) {}
        val frame = FrameLayout(this)
        frame.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
        val x = TextView(this).apply {
            text = "✕"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(0x99000000.toInt(), 14)
            setOnClickListener { removeWidget(id, frame) }
        }
        frame.addView(x, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
        })
        widgetBox.addView(frame, LinearLayout.LayoutParams(MATCH, hPx).apply { bottomMargin = dp(10) })
    }

    private fun removeWidget(id: Int, v: View) {
        widgetBox.removeView(v)
        forgetWidget(id)
    }

    // ---------- Cells ----------
    inner class VH(
        val box: LinearLayout, val frame: FrameLayout, val img: ImageView,
        val label: TextView, val badge: TextView
    ) : RecyclerView.ViewHolder(box)

    private fun makeVH(ctx: Context): VH {
        val size = if (iconPx > 0) iconPx else iconSize()
        val img = ImageView(ctx)
        val badge = TextView(ctx).apply {
            textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(0xFFFF3B30.toInt(), 10)
            setPadding(dp(5), 0, dp(5), 0); minWidth = dp(20)
            visibility = View.GONE
        }
        val frame = FrameLayout(ctx).apply {
            addView(img, FrameLayout.LayoutParams(size, size))
            addView(badge, FrameLayout.LayoutParams(WRAP, dp(20), Gravity.TOP or Gravity.END))
        }
        val label = TextView(ctx).apply {
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(8))
            addView(frame, LinearLayout.LayoutParams(size, size))
            addView(label, LinearLayout.LayoutParams(MATCH, WRAP))
            layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
        }
        press(box)
        return VH(box, frame, img, label, badge)
    }

    // Icon size is applied at bind time, so recycled holders never keep a stale size.
    private fun fit(h: VH) {
        val s = if (iconPx > 0) iconPx else iconSize()
        val fl = h.frame.layoutParams
        if (fl.width != s || fl.height != s) { fl.width = s; fl.height = s; h.frame.layoutParams = fl }
        val il = h.img.layoutParams
        if (il.width != s || il.height != s) { il.width = s; il.height = s; h.img.layoutParams = il }
    }

    private fun setBadge(h: VH, n: Int) {
        if (n > 0) { h.badge.text = if (n > 9) "9+" else n.toString(); h.badge.visibility = View.VISIBLE }
        else h.badge.visibility = View.GONE
    }

    private fun badgeOf(e: Entry?): Int = when (e) {
        is AppEntry -> Badges.get(e.pkg)
        is FolderEntry -> e.pkgs.sumOf { Badges.get(it) }
        else -> 0
    }

    private fun bindApp(h: VH, app: AppItem) {
        fit(h)
        h.img.setImageBitmap(app.icon)
        h.label.text = app.label
        h.label.visibility = if (labelsOn) View.VISIBLE else View.GONE
        setBadge(h, Badges.get(app.pkg))
    }

    private fun bindFolder(h: VH, f: FolderEntry) {
        fit(h)
        val key = f.pkgs.joinToString(",") + "|" + colorful
        val bmp = folderCache.getOrPut(key) {
            IconMaker.folder(this, f.pkgs.mapNotNull { byPkg[it]?.icon }, colorful)
        }
        h.img.setImageBitmap(bmp)
        h.label.text = f.name
        h.label.visibility = if (labelsOn) View.VISIBLE else View.GONE
        setBadge(h, badgeOf(f))
    }

    // ---------- Pager ----------
    private fun pageCount() = maxOf(1, (model.items.size + cap() - 1) / cap())
    private fun pageSize(page: Int) =
        maxOf(0, minOf(model.items.size, (page + 1) * cap()) - page * cap())

    inner class Plain(v: View) : RecyclerView.ViewHolder(v)

    inner class PagerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = 1 + pageCount()
        override fun getItemViewType(position: Int) = if (position == 0) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val lp = ViewGroup.LayoutParams(MATCH, MATCH)
            return if (viewType == 0) {
                Plain(FrameLayout(parent.context).apply { layoutParams = lp })
            } else {
                val rv = RecyclerView(parent.context).apply {
                    layoutParams = lp
                    layoutManager = GridLayoutManager(parent.context, cols())
                    overScrollMode = View.OVER_SCROLL_NEVER
                    setHasFixedSize(true)
                    setItemViewCacheSize(10)
                    setRecycledViewPool(pagePool)
                }
                ItemTouchHelper(DragCb()).attachToRecyclerView(rv)
                Plain(rv)
            }
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            if (position == 0) {
                val box = h.itemView as FrameLayout
                (widgetScroll.parent as? ViewGroup)?.removeView(widgetScroll)
                box.addView(widgetScroll, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                val rv = h.itemView as RecyclerView
                (rv.layoutManager as GridLayoutManager).spanCount = cols()
                rv.adapter = PageGridAdapter(position - 1)
            }
        }
    }

    inner class PageGridAdapter(val page: Int) : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = pageSize(page)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = makeVH(parent.context)

        override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty()) setBadge(h, badgeOf(model.items.getOrNull(page * cap() + position)))
            else super.onBindViewHolder(h, position, payloads)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = model.items.getOrNull(page * cap() + position) ?: return
            when (e) {
                is AppEntry -> {
                    val app = byPkg[e.pkg]
                    if (app != null) {
                        bindApp(h, app)
                        h.box.setOnClickListener { launch(h.img, app.pkg) }
                    } else {
                        h.img.setImageDrawable(null); h.label.text = ""; h.badge.visibility = View.GONE
                        h.box.setOnClickListener(null)
                    }
                }
                is FolderEntry -> {
                    bindFolder(h, e)
                    h.box.setOnClickListener { openFolder(e) }
                }
            }
        }
    }

    inner class DragCb : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
    ) {
        private var moved = false

        override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val a = rv.adapter as? PageGridAdapter ?: return false
            val from = vh.bindingAdapterPosition
            val to = target.bindingAdapterPosition
            if (from < 0 || to < 0) return false
            model.move(a.page * cap() + from, a.page * cap() + to)
            a.notifyItemMoved(from, to)
            moved = true
            return true
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

        override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
            super.onSelectedChanged(vh, actionState)
            if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                moved = false
                vh?.itemView?.animate()?.scaleX(1.12f)?.scaleY(1.12f)?.setDuration(120)?.start()
            }
        }

        override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
            super.clearView(rv, vh)
            vh.itemView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            val a = rv.adapter as? PageGridAdapter ?: return
            val pos = vh.bindingAdapterPosition
            if (moved) {
                model.save()
                moved = false
            } else if (pos >= 0) {
                showMenu(a.page * cap() + pos)
            }
        }
    }

    inner class SearchAdapter : RecyclerView.Adapter<VH>() {
        private var all: List<AppItem> = emptyList()
        private var items: List<AppItem> = emptyList()
        private var q = ""
        fun submit(l: List<AppItem>) { all = l; filter(q) }
        fun filter(query: String) {
            q = query
            val k = query.trim().lowercase()
            items = if (k.isEmpty()) all else all.filter { it.label.lowercase().contains(k) }
            notifyDataSetChanged()
        }
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = makeVH(parent.context)
        override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty()) items.getOrNull(position)?.let { setBadge(h, Badges.get(it.pkg)) }
            else super.onBindViewHolder(h, position, payloads)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val app = items[position]
            bindApp(h, app)
            h.box.setOnClickListener { launch(h.img, app.pkg) }
            h.box.setOnLongClickListener { chooseFolder(app, true); true }
        }
    }

    // ---------- Menus and folders ----------
    private fun askText(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("تأیید") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) ok(t)
            }
            .setNegativeButton("لغو", null).show()
    }

    // One dialog for everything: new folder, any existing folder, and (from search) app info / uninstall.
    private fun chooseFolder(app: AppItem, extras: Boolean) {
        val folders = model.items.filterIsInstance<FolderEntry>()
        val names = ArrayList<String>()
        names.add("➕  ساخت پوشهٔ جدید")
        folders.forEach { names.add("📁  " + it.name) }
        if (extras) { names.add("اطلاعات برنامه"); names.add("حذف برنامه") }
        AlertDialog.Builder(this).setTitle(app.label).setItems(names.toTypedArray()) { _, w ->
            when {
                w == 0 -> askText("نام پوشه", "") { n ->
                    model.putInNewFolder(app.pkg, n); refresh(); toast("پوشهٔ «$n» ساخته شد")
                }
                w <= folders.size -> {
                    val f = folders[w - 1]
                    model.putInFolder(app.pkg, f); refresh(); toast("به «" + f.name + "» اضافه شد")
                }
                else -> {
                    val uri = Uri.parse("package:" + app.pkg)
                    if (w == folders.size + 1) safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    else safeStart(Intent(Intent.ACTION_DELETE, uri))
                }
            }
        }.show()
    }

    private fun showMenu(index: Int) {
        val e = model.items.getOrNull(index) ?: return
        if (e is AppEntry) {
            val app = byPkg[e.pkg] ?: return
            val opts = arrayOf(
                "اطلاعات برنامه", "حذف برنامه", "پنهان کردن از لانچر", "ساخت پوشهٔ جدید",
                "افزودن به پوشه", "انتقال به صفحهٔ بعد", "انتقال به صفحهٔ قبل"
            )
            AlertDialog.Builder(this).setTitle(app.label).setItems(opts) { _, w ->
                val uri = Uri.parse("package:" + e.pkg)
                when (w) {
                    0 -> safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    1 -> safeStart(Intent(Intent.ACTION_DELETE, uri))
                    2 -> {
                        val set = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
                        set.add(e.pkg)
                        prefs.edit().putStringSet("hidden", set).apply()
                        reload(true)
                    }
                    3 -> askText("نام پوشه", "") { name -> model.newFolder(e.pkg, name); refresh() }
                    4 -> chooseFolder(app, false)
                    5 -> { model.moveByPages(index, 1, cap()); refresh() }
                    6 -> { model.moveByPages(index, -1, cap()); refresh() }
                }
            }.show()
        } else if (e is FolderEntry) {
            val opts = arrayOf("باز کردن", "تغییر نام", "حذف پوشه", "انتقال به صفحهٔ بعد", "انتقال به صفحهٔ قبل")
            AlertDialog.Builder(this).setTitle(e.name).setItems(opts) { _, w ->
                when (w) {
                    0 -> openFolder(e)
                    1 -> askText("نام جدید", e.name) { n -> e.name = n; refresh() }
                    2 -> { model.deleteFolder(e); refresh() }
                    3 -> { model.moveByPages(index, 1, cap()); refresh() }
                    4 -> { model.moveByPages(index, -1, cap()); refresh() }
                }
            }.show()
        }
    }

    private fun openFolder(f: FolderEntry) {
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        var dlg: AlertDialog? = null
        f.pkgs.toList().forEach { pkg ->
            val app = byPkg[pkg] ?: return@forEach
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            cell.addView(ImageView(this).apply { setImageBitmap(app.icon) }, LinearLayout.LayoutParams(dp(64), dp(64)))
            cell.addView(TextView(this).apply {
                text = app.label; textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(72), WRAP))
            cell.setOnClickListener { dlg?.dismiss(); launch(it, pkg) }
            cell.setOnLongClickListener {
                dlg?.dismiss()
                model.removeFromFolder(f, pkg)
                refresh()
                true
            }
            grid.addView(cell)
        }
        dlg = AlertDialog.Builder(this)
            .setTitle(f.name + "  (نگه‌دارید تا بیرون بیاید)")
            .setView(grid)
            .show()
    }
}
