package com.ultratony.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable

/**
 * Wallpaper drawable: center-crop (never stretched, always sharp) with the dark
 * scrim baked into the background layer, so icons and text are NOT dimmed.
 */
class BgDrawable(private val bmp: Bitmap, dim: Int = 0x40000000) : Drawable() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val dimPaint = Paint().apply { color = dim }
    private val m = Matrix()

    override fun onBoundsChange(b: Rect) {
        if (b.isEmpty) return
        val s = maxOf(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val dx = b.left + (b.width() - bmp.width * s) / 2f
        val dy = b.top + (b.height() - bmp.height * s) / 2f
        m.setScale(s, s)
        m.postTranslate(dx, dy)
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        c.save()
        c.clipRect(b)
        c.drawBitmap(bmp, m, paint)
        c.drawRect(b, dimPaint)
        c.restore()
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
