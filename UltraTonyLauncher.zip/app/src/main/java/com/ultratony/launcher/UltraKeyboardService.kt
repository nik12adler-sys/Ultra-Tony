package com.ultratony.launcher

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class UltraKeyboardService : InputMethodService() {
    private var fa = true
    private var shift = false
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private val faRows = listOf("۱۲۳۴۵۶۷۸۹۰", "ضصثقفغعهخحجچ", "شسیبلاتنمکگ", "ظطزرذدپوژ")
    private val enRows = listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF12141C.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        render()
        return root
    }

    private fun render() {
        root.removeAllViews()
        val rows = if (fa) faRows else enRows
        root.addView(row(rows[0].map { keyChar(it) }))
        root.addView(row(rows[1].map { keyChar(it) }))
        root.addView(row(rows[2].map { keyChar(it) }))
        val r3 = ArrayList<View>()
        if (!fa) r3.add(key(if (shift) "⬆" else "⇧", 1.5f) { shift = !shift; render() })
        rows[3].forEach { r3.add(keyChar(it)) }
        r3.add(key("⌫", 1.5f, repeat = true) { currentInputConnection?.deleteSurroundingText(1, 0) })
        root.addView(row(r3))
        root.addView(row(listOf(
            key(if (fa) "FA" else "EN", 1.5f) { fa = !fa; shift = false; render() },
            key(if (fa) "،" else ",", 1f) { type(if (fa) "،" else ",") },
            key(if (fa) "فاصله" else "space", 5f) { type(" ") },
            key(if (fa) "." else ".", 1f) { type(".") },
            key("⏎", 1.5f) { enter() }
        )))
    }

    private fun type(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun row(keys: List<View>) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        keys.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun keyChar(c: Char): View {
        val shown = if (!fa && shift) c.uppercaseChar().toString() else c.toString()
        return key(shown, 1f) {
            type(shown)
            if (shift) { shift = false; render() }
        }
    }

    private fun key(label: String, weight: Float, repeat: Boolean = false, action: () -> Unit): View {
        val tick = object : Runnable {
            override fun run() { action(); handler.postDelayed(this, 55) }
        }
        return TextView(this).apply {
            text = label; textSize = 18f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(0xFF2A2E3D.toInt()); cornerRadius = dp(10).toFloat() }
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start()
                        action()
                        if (repeat) handler.postDelayed(tick, 350)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        handler.removeCallbacks(tick)
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(OvershootInterpolator()).start()
                    }
                }
                true
            }
        }
    }
}
