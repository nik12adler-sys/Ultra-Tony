package com.ultratony.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class CrashLogActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(14).toFloat() }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(filesDir, "crash.txt")
        val full = if (f.exists()) f.readText() else "هنوز خطایی ثبت نشده است."
        val shown = if (full.length > 2500) full.substring(0, 2500) else full

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0F1A.toInt())
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Ultra Tony Log"; textSize = 26f; setTextColor(Color.WHITE)
        })
        val row = LinearLayout(this)
        row.addView(btn("کپی متن") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("log", full))
            Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, dp(8), dp(4), dp(8)) })
        row.addView(btn("پاک کردن") {
            f.delete(); recreate()
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(8), 0, dp(8)) })
        root.addView(row)
        val sv = ScrollView(this)
        sv.addView(TextView(this).apply {
            text = shown; textSize = 14f; setTextColor(0xFFFFB4B4.toInt()); setTextIsSelectable(true)
        })
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
