package com.ultratony.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveBg(uri)
    }

    private fun saveBg(uri: Uri) {
        try {
            val dm = resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / (sample * 2) >= w && opts.outHeight / (sample * 2) >= h) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return
            val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
            val sw = Math.ceil((src.width * scale).toDouble()).toInt()
            val sh = Math.ceil((src.height * scale).toDouble()).toInt()
            val scaled = Bitmap.createScaledBitmap(src, maxOf(sw, w), maxOf(sh, h), true)
            val out = Bitmap.createBitmap(scaled, (scaled.width - w) / 2, (scaled.height - h) / 2, w, h)
            FileOutputStream(File(filesDir, "bg.jpg")).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            Toast.makeText(this, "پس‌زمینه تغییر کرد", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در انتخاب عکس", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(16).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = dp(10) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ut", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0F1A.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "تنظیمات Ultra Tony"; textSize = 24f; setTextColor(Color.WHITE)
        })

        root.addView(SwitchCompat(this).apply {
            text = "آیکن‌های رنگی"; textSize = 16f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("colorful", true)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("colorful", v).apply() }
        }, lp())

        var colsBtn: TextView? = null
        fun colsText() = "تعداد ستون‌ها: ${prefs.getInt("cols", 4)} (برای تغییر بزنید)"
        colsBtn = button(colsText()) {
            val now = prefs.getInt("cols", 4)
            prefs.edit().putInt("cols", if (now == 4) 5 else 4).apply()
            colsBtn?.text = colsText()
        }
        root.addView(colsBtn, lp())

        root.addView(SwitchCompat(this).apply {
            text = "نمایش نام برنامه‌ها"; textSize = 16f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("labels", true)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("labels", v).apply() }
        }, lp())
        root.addView(button("انتخاب عکس پس‌زمینه") { picker.launch("image/*") }, lp())
        root.addView(button("حذف عکس پس‌زمینه") {
            File(filesDir, "bg.jpg").delete()
            Toast.makeText(this, "حذف شد", Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("تغییر رنگ پس‌زمینهٔ پیش‌فرض") {
            prefs.edit().putInt("bgGrad", (prefs.getInt("bgGrad", 0) + 1) % 4).apply()
        }, lp())
        root.addView(button("تغییر اندازهٔ آیکن‌ها (کوچک، متوسط، بزرگ)") {
            val now = prefs.getInt("iconDp", 60)
            prefs.edit().putInt("iconDp", when (now) { 52 -> 60; 60 -> 68; else -> 52 }).apply()
        }, lp())
        root.addView(button("نمایش دوبارهٔ برنامه‌های پنهان") {
            prefs.edit().remove("hidden").apply()
            Toast.makeText(this, "انجام شد", Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("پک آیکن (Icon Pack)") {
            val packs = IconPack.list(this)
            if (packs.isEmpty()) Toast.makeText(this, "پک آیکنی روی گوشی نصب نیست", Toast.LENGTH_SHORT).show()
            val names = ArrayList<String>()
            val pkgs = ArrayList<String?>()
            names.add("بدون پک (پشم Ultra Tony)"); pkgs.add(null)
            packs.forEach { names.add(it.second); pkgs.add(it.first) }
            AlertDialog.Builder(this).setTitle("پک آیکن").setItems(names.toTypedArray()) { _, i ->
                val ed = prefs.edit()
                val chosen = pkgs[i]
                if (chosen == null) ed.remove("iconpack") else ed.putString("iconpack", chosen)
                ed.apply()
            }.show()
        }, lp())
        root.addView(button("فعال‌سازی نقطهٔ اعلان روی آیکن‌ها") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, lp())
        root.addView(button("فعال‌سازی کیبورد Ultra Tony") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        root.addView(button("انتخاب کیبورد فعال") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())
        root.addView(button("تنظیم به‌عنوان لانچر پیش‌فرض") {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }, lp())
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0F1A.toInt()); addView(root) })
    }
}
