package com.ultratony.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.DisplayMetrics
import android.net.Uri
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.pm.PackageManager
import android.widget.EditText
import android.widget.LinearLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveBg(uri)
    }

    // Runs off the UI thread (big photos used to freeze the screen), honours EXIF rotation,
    // and keeps full screen resolution so the wallpaper stays sharp.
    @Suppress("DEPRECATION")
    private fun saveBg(uri: Uri) {
        Thread {
            var done = false
            try {
                val rm = DisplayMetrics()
                windowManager.defaultDisplay.getRealMetrics(rm)
                val w = rm.widthPixels
                val h = rm.heightPixels

                val rot = try {
                    contentResolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val degrees = when (rot) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                val swap = degrees == 90f || degrees == 270f

                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                val sw0 = if (swap) opts.outHeight else opts.outWidth
                val sh0 = if (swap) opts.outWidth else opts.outHeight
                var sample = 1
                while (sw0 / (sample * 2) >= w && sh0 / (sample * 2) >= h) sample *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
                var src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                if (src != null) {
                    if (degrees != 0f) {
                        val mtx = Matrix().apply { postRotate(degrees) }
                        src = Bitmap.createBitmap(src, 0, 0, src.width, src.height, mtx, true)
                    }
                    val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
                    val tw = maxOf(Math.ceil((src.width * scale).toDouble()).toInt(), w)
                    val th = maxOf(Math.ceil((src.height * scale).toDouble()).toInt(), h)
                    val scaled = if (tw == src.width && th == src.height) src else Bitmap.createScaledBitmap(src, tw, th, true)
                    val out = Bitmap.createBitmap(scaled, (scaled.width - w) / 2, (scaled.height - h) / 2, w, h)
                    FileOutputStream(File(filesDir, "bg.jpg")).use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    done = true
                }
            } catch (e: Throwable) {
                done = false
            }
            runOnUiThread {
                Toast.makeText(this, if (done) "پس‌زمینه تغییر کرد" else "خطا در انتخاب عکس", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyImport(entries: List<Entry>, note: String = "") {
        val prefs = getSharedPreferences("ut", Context.MODE_PRIVATE)
        LayoutImport.apply(prefs, entries)
        val folders = entries.count { it is FolderEntry }
        Toast.makeText(this, "$folders پوشه وارد شد. به صفحهٔ اصلی برگردید. $note", Toast.LENGTH_LONG).show()
    }

    private fun importFromLauncher(askPermission: Boolean) {
        val src = LayoutImport.sources(this)
        for (s in src) {
            val r = LayoutImport.read(this, s)
            if (r != null) { applyImport(r); return }
        }
        val perms = src.mapNotNull { it.permission }.distinct().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (askPermission && perms.isNotEmpty()) {
            try { ActivityCompat.requestPermissions(this, perms.toTypedArray(), 77); return } catch (_: Exception) {}
        }
        manualImport()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77) importFromLauncher(false)
    }

    private fun manualImport() {
        val et = EditText(this).apply {
            hint = "ابزار: ماشین حساب، ساعت\nشبکه‌های اجتماعی: اینستاگرام، تلگرام"
            minLines = 6; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this)
            .setTitle("لانچر قبلی قابل خواندن نبود")
            .setMessage("اندروید به برنامه‌ها اجازهٔ خواندن پوشه‌های لانچر دیگر را نمی‌دهد. هر پوشه را در یک خط بنویسید: نام پوشه، دو نقطه، نام برنامه‌ها با کاما.")
            .setView(et)
            .setPositiveButton("وارد کن") { _, _ ->
                val (entries, missing) = LayoutImport.fromText(this, et.text.toString())
                if (entries.isEmpty()) {
                    Toast.makeText(this, "چیزی پیدا نشد", Toast.LENGTH_SHORT).show()
                } else {
                    applyImport(entries, if (missing.isEmpty()) "" else "پیدا نشد: " + missing.take(5).joinToString("، "))
                }
            }
            .setNegativeButton("لغو", null).show()
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { Toast.makeText(this, "این گزینه در این گوشی نیست", Toast.LENGTH_SHORT).show() }
    }

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 19f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(20), dp(18), dp(20))
        background = GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(18).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = dp(12) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ut", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0F1A.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "تنظیمات Ultra Tony"; textSize = 30f; setTextColor(Color.WHITE)
        })

        root.addView(SwitchCompat(this).apply {
            text = "آیکن‌های رنگی"; textSize = 19f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("colorful", true)
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("colorful", v).apply() }
        }, lp())

        var colsBtn: TextView? = null
        fun colsText() = "تعداد ستون‌ها: ${prefs.getInt("cols", 4)} (برای تغییر بزنید)"
        colsBtn = button(colsText()) {
            val now = prefs.getInt("cols", 4)
            prefs.edit().putInt("cols", if (now == 4) 5 else 4).apply()
            colsBtn?.text = colsText()
        }
        root.addView(colsBtn, lp())

        root.addView(SwitchCompat(this).apply {
            text = "نمایش نام برنامه‌ها"; textSize = 19f; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("labels", true)
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("labels", v).apply() }
        }, lp())
        root.addView(button("انتخاب عکس پس‌زمینه") { picker.launch("image/*") }, lp())
        root.addView(button("حذف عکس پس‌زمینه") {
            val ok = File(filesDir, "bg.jpg").delete()
            Toast.makeText(this, if (ok) "حذف شد" else "عکسی برای حذف نیست", Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("تغییر رنگ پس‌زمینهٔ پیش‌فرض") {
            prefs.edit().putInt("bgGrad", (prefs.getInt("bgGrad", 0) + 1) % 4).apply()
            Toast.makeText(this, "رنگ پس‌زمینه تغییر کرد", Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("تغییر اندازهٔ آیکن‌ها (کوچک، متوسط، بزرگ)") {
            val now = prefs.getInt("iconDp", 68)
            val next = when (now) { 60 -> 68; 68 -> 76; else -> 60 }
            prefs.edit().putInt("iconDp", next).apply()
            Toast.makeText(this, when (next) { 60 -> "اندازه: کوچک"; 68 -> "اندازه: متوسط"; else -> "اندازه: بزرگ" }, Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("نمایش دوبارهٔ برنامه‌های پنهان") {
            prefs.edit().remove("hidden").apply()
            Toast.makeText(this, "انجام شد", Toast.LENGTH_SHORT).show()
        }, lp())
        root.addView(button("پک آیکن (Icon Pack)") {
            val packs = IconPack.list(this)
            if (packs.isEmpty()) {
                Toast.makeText(this, "پک آیکنی روی گوشی نصب نیست", Toast.LENGTH_SHORT).show()
                return@button
            }
            val names = ArrayList<String>()
            val pkgs = ArrayList<String?>()
            names.add("بدون پک (پشم Ultra Tony)"); pkgs.add(null)
            packs.forEach { names.add(it.second); pkgs.add(it.first) }
            AlertDialog.Builder(this).setTitle("پک آیکن").setItems(names.toTypedArray()) { _, i ->
                val ed = prefs.edit()
                val chosen = pkgs[i]
                if (chosen == null) ed.remove("iconpack") else ed.putString("iconpack", chosen)
                ed.apply()
            }.show()
        }, lp())
        root.addView(button("وارد کردن پوشه‌ها از لانچر قبلی") { importFromLauncher(true) }, lp())
        root.addView(button("وارد کردن پوشه‌ها با متن") { manualImport() }, lp())
        root.addView(button("فعال‌سازی نقطهٔ اعلان روی آیکن‌ها") {
            safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }, lp())
        root.addView(button("فعال‌سازی کیبورد Ultra Tony") {
            safeStart(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        root.addView(button("انتخاب کیبورد فعال") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())
        root.addView(button("تنظیم به‌عنوان لانچر پیش‌فرض") {
            safeStart(Intent(Settings.ACTION_HOME_SETTINGS))
        }, lp())
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0B0F1A.toInt()); addView(root) })
    }
}
