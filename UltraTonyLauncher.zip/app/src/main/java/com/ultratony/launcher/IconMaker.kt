package com.ultratony.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.core.graphics.ColorUtils
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String, val icon: Bitmap)

/** Built-in icon styles. FUR is the original Ultra Tony wool look. */
enum class IconStyle(val key: String, val title: String) {
    FUR("fur", "پشمی (Ultra Tony)"),
    GLASS("glass", "لیکوئید گلس آیفون (روشن)"),
    GLASS_DARK("glassdark", "لیکوئید گلس آیفون (تیره)"),
    GRADIENT("gradient", "گرادیان رنگی"),
    NEON("neon", "نئون"),
    CLAY("clay", "خمیری نرم (Clay)"),
    PLAIN("plain", "ساده (آیکن اصلی برنامه)");

    companion object {
        fun from(k: String?): IconStyle = values().firstOrNull { it.key == k } ?: FUR
    }
}

object IconMaker {
    private val palette = intArrayOf(
        0xFFFF6B6B.toInt(), 0xFFFFA94D.toInt(), 0xFFFFD43B.toInt(), 0xFF69DB7C.toInt(),
        0xFF38D9A9.toInt(), 0xFF4DABF7.toInt(), 0xFF748FFC.toInt(), 0xFFDA77F2.toInt(),
        0xFFF783AC.toInt(), 0xFFA9E34B.toInt()
    )
    private val cache = HashMap<String, Bitmap>()
    private var fur: Bitmap? = null
    private var S = 0

    private fun size(ctx: Context): Int {
        if (S == 0) S = (88 * ctx.resources.displayMetrics.density).roundToInt().coerceIn(176, 320)
        return S
    }

    private fun color(pkg: String) = palette[(pkg.hashCode() and 0x7fffffff) % palette.size]

    private fun furBitmap(ctx: Context): Bitmap =
        fur ?: BitmapFactory.decodeResource(ctx.resources, R.drawable.fur).also { fur = it }

    fun style(ctx: Context): IconStyle =
        IconStyle.from(ctx.getSharedPreferences("ut", Context.MODE_PRIVATE).getString("iconstyle", null))

    // ---------- shapes & helpers ----------

    /** iOS-like squircle (superellipse). */
    private fun squircle(r: RectF): Path {
        val p = Path()
        val cx = r.centerX().toDouble(); val cy = r.centerY().toDouble()
        val a = r.width() / 2.0; val b = r.height() / 2.0
        val e = 2.0 / 5.0
        val steps = 96
        for (i in 0 until steps) {
            val th = 2.0 * Math.PI * i / steps
            val ct = Math.cos(th); val st = Math.sin(th)
            val x = cx + a * Math.signum(ct) * Math.pow(Math.abs(ct), e)
            val y = cy + b * Math.signum(st) * Math.pow(Math.abs(st), e)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
        return p
    }

    private fun aa() = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Soft shadow under the shape; the inside is cleared so translucent bodies stay clean. */
    private fun dropShadow(c: Canvas, path: Path, s: Int, alpha: Int) {
        val sh = aa().apply {
            color = Color.argb(alpha, 0, 0, 0)
            maskFilter = BlurMaskFilter(s * 0.035f, BlurMaskFilter.Blur.NORMAL)
        }
        c.save(); c.translate(0f, s * 0.02f); c.drawPath(path, sh); c.restore()
        val clear = aa().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        c.drawPath(path, clear)
    }

    private fun rimLight(c: Canvas, path: Path, s: Int, strong: Boolean) {
        val rim = aa().apply {
            style = Paint.Style.STROKE
            strokeWidth = s * 0.02f
            shader = LinearGradient(
                0f, 0f, s.toFloat(), s.toFloat(),
                intArrayOf(
                    if (strong) 0xF0FFFFFF.toInt() else 0xB0FFFFFF.toInt(),
                    0x28FFFFFF, 0x18FFFFFF,
                    if (strong) 0xB0FFFFFF.toInt() else 0x80FFFFFF.toInt()
                ),
                floatArrayOf(0f, 0.38f, 0.62f, 1f), Shader.TileMode.CLAMP
            )
        }
        c.drawPath(path, rim)
    }

    private fun topHighlight(c: Canvas, rect: RectF, s: Int, alpha: Int) {
        val inset = s * 0.025f
        val inner = squircle(RectF(rect.left + inset, rect.top + inset, rect.right - inset, rect.bottom - inset))
        val hl = aa().apply {
            shader = LinearGradient(
                0f, rect.top, 0f, rect.top + s * 0.42f,
                Color.argb(alpha, 255, 255, 255), 0x00FFFFFF, Shader.TileMode.CLAMP
            )
        }
        c.drawPath(inner, hl)
    }

    private fun maskOutside(c: Canvas, path: Path) {
        val inv = Path(path).apply { fillType = Path.FillType.INVERSE_WINDING }
        val p = aa().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        c.drawPath(inv, p)
    }

    // ---------- backgrounds ----------

    /** Liquid-glass look: translucent tinted body, specular sheen, bright refractive rim. */
    private fun glass(c: Canvas, s: Int, tint: Int, dark: Boolean) {
        val m = s * 0.06f
        val rect = RectF(m, m, s - m, s - m)
        val path = squircle(rect)
        dropShadow(c, path, s, if (dark) 90 else 70)

        val c1 = if (dark) ColorUtils.blendARGB(0xFF2C3654.toInt(), tint, 0.22f)
        else ColorUtils.blendARGB(tint, Color.WHITE, 0.25f)
        val c2 = if (dark) ColorUtils.blendARGB(0xFF10151F.toInt(), tint, 0.22f) else tint
        val body = aa().apply {
            shader = LinearGradient(
                0f, rect.top, 0f, rect.bottom,
                ColorUtils.setAlphaComponent(c1, if (dark) 150 else 100),
                ColorUtils.setAlphaComponent(c2, if (dark) 215 else 165),
                Shader.TileMode.CLAMP
            )
        }
        c.drawPath(path, body)

        c.save()
        c.clipPath(path)
        val glow = aa().apply {
            shader = RadialGradient(s * 0.5f, rect.bottom, s * 0.55f,
                intArrayOf(0x55FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        }
        c.drawRect(rect, glow)
        val sheen = aa().apply {
            shader = RadialGradient(s * 0.30f, rect.top, s * 0.75f,
                intArrayOf(0x88FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        }
        c.drawRect(rect, sheen)
        c.restore()

        topHighlight(c, rect, s, 0x66)
        rimLight(c, path, s, !dark)
    }

    private fun gradientBg(c: Canvas, s: Int, tint: Int) {
        val m = s * 0.06f
        val rect = RectF(m, m, s - m, s - m)
        val path = squircle(rect)
        dropShadow(c, path, s, 60)
        val p = aa().apply {
            shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                ColorUtils.blendARGB(tint, Color.WHITE, 0.30f),
                ColorUtils.blendARGB(tint, Color.BLACK, 0.30f),
                Shader.TileMode.CLAMP
            )
        }
        c.drawPath(path, p)
        topHighlight(c, rect, s, 0x44)
        c.drawPath(path, aa().apply {
            style = Paint.Style.STROKE; strokeWidth = s * 0.012f; color = 0x40FFFFFF
        })
    }

    private fun neonBg(c: Canvas, s: Int, tint: Int) {
        val m = s * 0.08f
        val rect = RectF(m, m, s - m, s - m)
        val path = squircle(rect)
        c.drawPath(path, aa().apply { color = 0xFF0A0E18.toInt() })
        c.drawPath(path, aa().apply {
            style = Paint.Style.STROKE; strokeWidth = s * 0.05f
            color = ColorUtils.setAlphaComponent(tint, 170)
            maskFilter = BlurMaskFilter(s * 0.035f, BlurMaskFilter.Blur.NORMAL)
        })
        c.drawPath(path, aa().apply {
            style = Paint.Style.STROKE; strokeWidth = s * 0.02f
            color = ColorUtils.blendARGB(tint, Color.WHITE, 0.35f)
        })
    }

    private fun clayBg(c: Canvas, s: Int, tint: Int) {
        val m = s * 0.06f
        val rect = RectF(m, m, s - m, s - m)
        val path = squircle(rect)
        dropShadow(c, path, s, 80)
        val base = ColorUtils.blendARGB(tint, Color.WHITE, 0.45f)
        c.drawPath(path, aa().apply {
            shader = LinearGradient(
                0f, rect.top, 0f, rect.bottom,
                ColorUtils.blendARGB(base, Color.WHITE, 0.35f), base, Shader.TileMode.CLAMP
            )
        })
        c.save()
        c.clipPath(path)
        c.drawRect(rect, aa().apply {
            shader = LinearGradient(0f, rect.bottom - s * 0.22f, 0f, rect.bottom,
                0x00000000, 0x38000000, Shader.TileMode.CLAMP)
        })
        c.drawRect(rect, aa().apply {
            shader = RadialGradient(s * 0.28f, s * 0.22f, s * 0.5f,
                intArrayOf(0x99FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        })
        c.restore()
        c.drawPath(path, aa().apply {
            style = Paint.Style.STROKE; strokeWidth = s * 0.012f; color = 0x50FFFFFF
        })
    }

    private fun drawBase(ctx: Context, c: Canvas, s: Int, style: IconStyle, tint: Int, colorful: Boolean) {
        when (style) {
            IconStyle.FUR -> {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                if (colorful) paint.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
                c.drawBitmap(furBitmap(ctx), null, Rect(0, 0, s, s), paint)
            }
            IconStyle.GLASS -> glass(c, s, tint, false)
            IconStyle.GLASS_DARK, IconStyle.PLAIN -> glass(c, s, tint, true)
            IconStyle.GRADIENT -> gradientBg(c, s, tint)
            IconStyle.NEON -> neonBg(c, s, tint)
            IconStyle.CLAY -> clayBg(c, s, tint)
        }
    }

    private fun drawFg(c: Canvas, s: Int, icon: Drawable, adaptiveSide: Float, normalSide: Float) {
        var fg: Drawable = icon
        var side = (s * normalSide).toInt()
        if (Build.VERSION.SDK_INT >= 26 && icon is AdaptiveIconDrawable) {
            val f = icon.foreground
            if (f != null) {
                fg = f
                side = (s * adaptiveSide).toInt()
            }
        }
        val off = (s - side) / 2
        fg.setBounds(off, off, off + side, off + side)
        fg.draw(c)
    }

    // ---------- public API ----------

    fun make(
        ctx: Context, pkg: String, comp: ComponentName, iconProvider: () -> Drawable,
        colorful: Boolean, pack: IconPack?, style: IconStyle = style(ctx)
    ): Bitmap {
        val S = size(ctx)
        val key = "$pkg|$colorful|${pack?.pkg}|${style.key}"
        synchronized(cache) { cache[key]?.let { return it } }
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val packIcon = pack?.find(comp)
        if (packIcon != null) {
            packIcon.setBounds(0, 0, S, S)
            packIcon.draw(c)
        } else if (style == IconStyle.PLAIN) {
            val icon = iconProvider()
            if (Build.VERSION.SDK_INT >= 26 && icon is AdaptiveIconDrawable) {
                icon.setBounds(0, 0, S, S)
                icon.draw(c)
            } else {
                c.drawColor(0xFF1C2230.toInt())
                val side = (S * 0.64f).toInt()
                val off = (S - side) / 2
                icon.setBounds(off, off, off + side, off + side)
                icon.draw(c)
            }
            maskOutside(c, squircle(RectF(0f, 0f, S.toFloat(), S.toFloat())))
        } else {
            val tint = if (colorful) color(pkg) else if (style == IconStyle.FUR) Color.WHITE else 0xFFB8C2D6.toInt()
            drawBase(ctx, c, S, style, tint, colorful)
            val adaptive = if (style == IconStyle.FUR) 0.90f else 0.92f
            drawFg(c, S, iconProvider(), adaptive, 0.52f)
        }
        synchronized(cache) { cache[key] = bmp }
        return bmp
    }

    fun folder(ctx: Context, kids: List<Bitmap>, colorful: Boolean): Bitmap {
        val S = size(ctx)
        val style = style(ctx)
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val tint = if (colorful) 0xFF748FFC.toInt() else if (style == IconStyle.FUR) Color.WHITE else 0xFFB8C2D6.toInt()
        drawBase(ctx, c, S, style, tint, colorful)
        val cell = (S * 0.34f).toInt()
        val gap = (S * 0.06f).toInt()
        val start = (S - cell * 2 - gap) / 2
        val p2 = Paint(Paint.FILTER_BITMAP_FLAG)
        kids.take(4).forEachIndexed { i, b ->
            val x = start + (i % 2) * (cell + gap)
            val y = start + (i / 2) * (cell + gap)
            c.drawBitmap(b, null, Rect(x, y, x + cell, y + cell), p2)
        }
        return bmp
    }

    fun loadApps(ctx: Context, colorful: Boolean): List<AppItem> {
        val pm = ctx.packageManager
        val prefs = ctx.getSharedPreferences("ut", Context.MODE_PRIVATE)
        val pack = IconPack.load(ctx, prefs.getString("iconpack", null))
        val style = IconStyle.from(prefs.getString("iconstyle", null))
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val pkg = it.activityInfo.packageName
                val comp = ComponentName(pkg, it.activityInfo.name)
                val bmp = try {
                    make(ctx, pkg, comp, { it.loadIcon(pm) }, colorful, pack, style)
                } catch (e: Throwable) {
                    furBitmap(ctx)
                }
                AppItem(it.loadLabel(pm).toString(), pkg, bmp)
            }
            .sortedBy { it.label.lowercase() }
    }
}
