package com.ultratony.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

data class AppItem(val label: String, val pkg: String, val icon: Bitmap)

object IconMaker {
    private val palette = intArrayOf(
        0xFFFF6B6B.toInt(), 0xFFFFA94D.toInt(), 0xFFFFD43B.toInt(), 0xFF69DB7C.toInt(),
        0xFF38D9A9.toInt(), 0xFF4DABF7.toInt(), 0xFF748FFC.toInt(), 0xFFDA77F2.toInt(),
        0xFFF783AC.toInt(), 0xFFA9E34B.toInt()
    )
    private val cache = HashMap<String, Bitmap>()
    private var fur: Bitmap? = null
    private const val S = 180

    private fun color(pkg: String) = palette[(pkg.hashCode() and 0x7fffffff) % palette.size]

    private fun furBitmap(ctx: Context): Bitmap =
        fur ?: BitmapFactory.decodeResource(ctx.resources, R.drawable.fur).also { fur = it }

    fun make(ctx: Context, pkg: String, comp: ComponentName, icon: Drawable, colorful: Boolean, pack: IconPack?): Bitmap {
        val key = "$pkg|$colorful|${pack?.pkg}"
        synchronized(cache) { cache[key]?.let { return it } }
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val packIcon = pack?.find(comp)
        if (packIcon != null) {
            packIcon.setBounds(0, 0, S, S)
            packIcon.draw(c)
        } else {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            if (colorful) paint.colorFilter = PorterDuffColorFilter(color(pkg), PorterDuff.Mode.MULTIPLY)
            c.drawBitmap(furBitmap(ctx), null, Rect(0, 0, S, S), paint)

            var fg: Drawable = icon
            var side = (S * 0.52f).toInt()
            if (Build.VERSION.SDK_INT >= 26 && icon is AdaptiveIconDrawable) {
                val f = icon.foreground
                if (f != null) {
                    fg = f
                    side = (S * 0.90f).toInt()
                }
            }
            val off = (S - side) / 2
            fg.setBounds(off, off, off + side, off + side)
            fg.draw(c)
        }
        synchronized(cache) { cache[key] = bmp }
        return bmp
    }

    fun folder(ctx: Context, kids: List<Bitmap>, colorful: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (colorful) paint.colorFilter = PorterDuffColorFilter(0xFF748FFC.toInt(), PorterDuff.Mode.MULTIPLY)
        c.drawBitmap(furBitmap(ctx), null, Rect(0, 0, S, S), paint)
        val cell = (S * 0.34f).toInt()
        val gap = (S * 0.06f).toInt()
        val start = (S - cell * 2 - gap) / 2
        val p2 = Paint(Paint.FILTER_BITMAP_FLAG)
        kids.take(4).forEachIndexed { i, b ->
            val x = start + (i % 2) * (cell + gap)
            val y = start + (i / 2) * (cell + gap)
            c.drawBitmap(b, null, Rect(x, y, x + cell, y + cell), p2)
        }
        return bmp
    }

    fun loadApps(ctx: Context, colorful: Boolean): List<AppItem> {
        val pm = ctx.packageManager
        val prefs = ctx.getSharedPreferences("ut", Context.MODE_PRIVATE)
        val pack = IconPack.load(ctx, prefs.getString("iconpack", null))
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val pkg = it.activityInfo.packageName
                val comp = ComponentName(pkg, it.activityInfo.name)
                AppItem(it.loadLabel(pm).toString(), pkg, make(ctx, pkg, comp, it.loadIcon(pm), colorful, pack))
            }
            .sortedBy { it.label.lowercase() }
    }
}
