package com.ultratony.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

/** Imports folders / app order from the phone's previous launcher (or from pasted text). */
object LayoutImport {

    class Source(val authority: String, val permission: String?)

    private val known = listOf(
        "com.miui.home.launcher.settings",
        "com.android.launcher3.settings",
        "com.google.android.apps.nexuslauncher.settings",
        "com.sec.android.app.launcher.settings",
        "com.android.launcher.settings",
        "com.huawei.android.launcher.settings"
    )

    @Suppress("DEPRECATION")
    fun sources(ctx: Context): List<Source> {
        val pm = ctx.packageManager
        val out = ArrayList<Source>()
        try {
            val homes = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
            ).map { it.activityInfo.packageName }.filter { it != ctx.packageName }.distinct()
            for (p in homes) {
                try {
                    val info = pm.getPackageInfo(p, PackageManager.GET_PROVIDERS)
                    info.providers?.forEach { pr ->
                        val a = pr.authority?.split(";")?.firstOrNull() ?: return@forEach
                        if (a.endsWith(".settings") || a.contains("launcher.settings")) {
                            out.add(Source(a, pr.readPermission))
                        }
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        for (a in known) if (out.none { it.authority == a }) out.add(Source(a, null))
        return out
    }

    private class Row(
        val id: Long, val title: String?, val pkg: String?, val container: Long,
        val screen: Int, val x: Int, val y: Int, val type: Int
    )

    private fun pkgOf(intent: String?): String? {
        if (intent.isNullOrEmpty()) return null
        return try {
            val i = Intent.parseUri(intent, 0)
            i.component?.packageName ?: i.`package`
        } catch (e: Exception) { null }
    }

    /** Returns the entries in home-screen order, or null if this source can't be read. */
    fun read(ctx: Context, s: Source): List<Entry>? {
        val uri = Uri.parse("content://" + s.authority + "/favorites")
        val c = try {
            ctx.contentResolver.query(uri, null, null, null, null)
        } catch (e: Throwable) { null } ?: return null
        val rows = ArrayList<Row>()
        try {
            val iId = c.getColumnIndex("_id")
            val iTitle = c.getColumnIndex("title")
            val iIntent = c.getColumnIndex("intent")
            val iCont = c.getColumnIndex("container")
            val iScreen = c.getColumnIndex("screen")
            val iX = c.getColumnIndex("cellX")
            val iY = c.getColumnIndex("cellY")
            val iType = c.getColumnIndex("itemType")
            if (iId < 0 || iCont < 0 || iType < 0) return null
            while (c.moveToNext()) {
                rows.add(Row(
                    c.getLong(iId),
                    if (iTitle >= 0) c.getString(iTitle) else null,
                    if (iIntent >= 0) pkgOf(c.getString(iIntent)) else null,
                    c.getLong(iCont),
                    if (iScreen >= 0) c.getInt(iScreen) else 0,
                    if (iX >= 0) c.getInt(iX) else 0,
                    if (iY >= 0) c.getInt(iY) else 0,
                    c.getInt(iType)
                ))
            }
        } catch (e: Throwable) {
            return null
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
        val order = compareBy<Row>({ it.screen }, { it.y }, { it.x })
        val byContainer = rows.groupBy { it.container }
        val out = ArrayList<Entry>()
        for (r in (byContainer[-100L] ?: emptyList()).sortedWith(order)) {
            if (r.type == 2) {
                val kids = (byContainer[r.id] ?: emptyList()).sortedWith(order).mapNotNull { it.pkg }
                if (kids.isNotEmpty()) out.add(FolderEntry(r.title?.takeIf { it.isNotBlank() } ?: "پوشه", kids.toMutableList()))
            } else if (r.pkg != null) {
                out.add(AppEntry(r.pkg))
            }
        }
        return if (out.isEmpty()) null else out
    }

    /** "Folder name: app1, app2" per line; a line without ':' is a single app. Returns entries + unmatched names. */
    fun fromText(ctx: Context, text: String): Pair<List<Entry>, List<String>> {
        val pm = ctx.packageManager
        val labels = LinkedHashMap<String, String>()
        try {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (r in pm.queryIntentActivities(q, PackageManager.MATCH_ALL)) {
                if (r.activityInfo.packageName == ctx.packageName) continue
                labels[r.loadLabel(pm).toString().trim().lowercase()] = r.activityInfo.packageName
            }
        } catch (_: Exception) {}
        val missing = ArrayList<String>()
        fun find(name: String): String? {
            val k = name.trim().lowercase()
            if (k.isEmpty()) return null
            labels[k]?.let { return it }
            val hit = labels.entries.firstOrNull { it.key.contains(k) || k.contains(it.key) }
            if (hit == null) missing.add(name.trim())
            return hit?.value
        }
        val out = ArrayList<Entry>()
        for (line in text.lines()) {
            val l = line.trim()
            if (l.isEmpty()) continue
            val colon = l.indexOfFirst { it == ':' || it == '：' }
            if (colon > 0) {
                val name = l.substring(0, colon).trim()
                val pkgs = l.substring(colon + 1).split(',', '،', '؛', ';')
                    .mapNotNull { find(it) }.distinct().toMutableList()
                if (pkgs.isNotEmpty()) out.add(FolderEntry(name, pkgs))
            } else {
                find(l)?.let { out.add(AppEntry(it)) }
            }
        }
        return Pair(out, missing)
    }

    fun apply(prefs: android.content.SharedPreferences, entries: List<Entry>) {
        val m = HomeModel(prefs)
        m.items.addAll(entries)
        m.save()
        prefs.edit().putLong("layoutVer", System.nanoTime()).apply()
    }
}
